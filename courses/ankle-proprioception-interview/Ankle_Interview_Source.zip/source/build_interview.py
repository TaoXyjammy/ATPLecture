from pathlib import Path
import json,io,zipfile
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
from PIL import Image
from docx import Document
from docx.shared import Pt as DPt
ROOT=Path(__file__).resolve().parent.parent
AS=Path(__file__).parent/'assets'
p=Presentation(str(Path(__file__).parent/'肌骨概述.pptx'))
for sid in list(p.slides._sldIdLst):
 p.part.drop_rel(sid.rId);p.slides._sldIdLst.remove(sid)
RED='FF4726';DEEP='A71D25';DARK='263442';GREY='697580';PALE='FFF3EF';WHITE='FFFFFF'
records=[]
def rect(s,x,y,w,h,c):
 z=s.shapes.add_shape(1,Inches(x),Inches(y),Inches(w),Inches(h));z.fill.solid();z.fill.fore_color.rgb=RGBColor.from_string(c);z.line.fill.background();return z
def text(s,x,y,w,h,t,size=23,color=DARK,bold=False,align=None):
 z=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));f=z.text_frame;f.word_wrap=True;f.margin_left=f.margin_right=Inches(.02);f.margin_top=Inches(.02);f.margin_bottom=0
 for i,a in enumerate(t.split('\n')):
  q=f.paragraphs[0] if i==0 else f.add_paragraph();q.text=a;q.font.name='Noto Sans CJK SC';q.font.size=Pt(size);q.font.bold=bold;q.font.color.rgb=RGBColor.from_string(color);q.space_after=Pt(12)
  if align is not None:q.alignment=align
 return z
def photo(s,name,x,y,w,h,region=(0,0,1,1)):
 path=AS/name;im=Image.open(path);iw,ih=im.size;l,t,r,b=region
 sw=(r-l)*iw;sh=(b-t)*ih;target=w/h
 if sw/sh>target:
  cut=(sw-sh*target)/iw/2;l+=cut;r-=cut
 else:
  cut=(sh-sw/target)/ih/2;t+=cut;b-=cut
 z=s.shapes.add_picture(str(path),Inches(x),Inches(y),Inches(w),Inches(h));z.crop_left=l;z.crop_top=t;z.crop_right=1-r;z.crop_bottom=1-b
 return z
def finish(s,title,seconds,script,source):
 n=len(records)+1
 tr=OxmlElement('p:transition');tr.set('spd','med');tr.append(OxmlElement('p:fade'));s._element.append(tr)
 s.notes_slide.notes_text_frame.text=script+'\n\n资料依据：'+source
 records.append({'slide':n,'title':title,'seconds':seconds,'script':script,'source':source})
def base(title,part):
 s=p.slides.add_slide(p.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor.from_string(WHITE)
 rect(s,0,0,13.333,.25,RED);text(s,.58,.45,8.7,.4,'运动损伤与预防  ·  踝关节扭伤',15,DEEP,True)
 text(s,11.0,.45,1.7,.4,part,14,GREY,False,PP_ALIGN.RIGHT)
 text(s,.58,1.12,12.2,.75,title,30,DARK,True)
 rect(s,.6,1.98,.78,.055,RED);rect(s,0,7.13,13.333,.07,RED)
 text(s,.62,6.82,10.4,.24,'谢淘  |  踝关节扭伤后的本体感觉与再损伤预防',10,GREY)
 text(s,12.05,6.78,.65,.3,f'{len(records)+1:02}',12,DEEP,True,PP_ALIGN.RIGHT)
 return s
def point(s,y,head,body,x=7.1,w=5.55):
 text(s,x,y,w,.43,head,23,DEEP,True);text(s,x,y+.55,w,.75,body,21)
# 1 — cover, using the supplied theme and its red family.
s=p.slides.add_slide(p.slide_layouts[6]);photo(s,'football_hero.png',5.25,0,8.08,7.5,(.16,0,1,1));rect(s,0,0,5.65,7.5,DEEP)
rect(s,.6,.65,.72,.06,WHITE);text(s,.63,.98,4.5,.5,'运动损伤与预防',22,WHITE,True)
text(s,.63,2.0,4.5,1.65,'不痛了，为什么\n还会再次扭伤？',34,WHITE,True)
text(s,.65,4.3,4.35,1.1,'踝关节扭伤后的本体感觉\n与再损伤预防',24,WHITE)
text(s,.65,6.25,3.8,.5,'主讲：谢淘',23,WHITE);text(s,11.65,7.12,1.2,.2,'AI情境图',9,WHITE)
finish(s,'不痛了，为什么还会再次扭伤？',35,'同学们好，我是谢淘。今天我们学习踝关节扭伤中的一个具体问题：不痛了，为什么还会再次扭伤？很多同学把疼痛消失当作恢复的终点，但运动不仅要求脚踝能够承重，还要求我们在落地和变向时保持控制。接下来，我们结合教材，认识本体感觉在再损伤预防中的作用。','用户教材《运动康复评定学》踝关节损伤，第164—165页。封面为AI生成训练情境，不表示损伤实录。')
# 2 — actual event imagery plus a clearly fictional recovery question.
s=base('走路已经不痛，变向时却仍然“不稳”','损伤情境')
photo(s,'ankle_frames.gif',1.0,2.23,4.45,4.24,(.07,.055,.93,.855))
text(s,.73,6.52,5.5,.22,'真实比赛研究图帧序列（非连续录像）',12,GREY)
point(s,2.5,'扭伤后，疼痛逐渐减轻','平地步行恢复，准备重新参加运动。')
point(s,4.12,'但在落地、变向时仍感到不稳','这时，功能是否已经充分恢复？')
text(s,7.1,5.95,5.5,.5,'疼痛缓解 ≠ 运动控制充分恢复',24,DEEP,True)
finish(s,'走路已经不痛，变向时却仍然“不稳”',65,'先看左边的真实比赛研究图帧，注意运动员落地时足与地面的关系。这组图只说明损伤发生的情境，不代表这名运动员之后的恢复情况。现在把问题放到我们身边：一名同学扭伤后经过处理，平地走路已经不痛，但重新参加训练时，变向仍觉得脚踝发虚。他能否仅凭不痛，就认定已经完全恢复？请大家先保留判断。今天的关键就是区分疼痛变化与运动控制的恢复。足球是例子，同样的问题也会出现在篮球、跑跳和日常踩空之后。','教材第164—165页；比赛图帧：Buckthorpe等，2025，图2(c1—c4)，https://pmc.ncbi.nlm.nih.gov/articles/PMC12582226/ ，CC BY 4.0。恢复情境为虚构课堂案例。')
# 3 — detailed existing 3D medical image, not an invented ligament drawing.
s=base('跖屈位内翻，为什么容易伤到外侧？','损伤机制')
# Crop only to the ankle portion of the Chinese-labelled medical illustration.
z=s.shapes.add_picture(str(AS/'foot_anatomy.png'),Inches(.9),Inches(2.25),Inches(4.1),Inches(4.1));z.crop_bottom=.50
text(s,.75,6.47,5.8,.25,'三维医学插图：BruceBlaus／GnolizX，CC BY 3.0',11,GREY)
point(s,2.4,'典型姿势：跖屈位内翻','距骨后部较窄，跖屈时关节相对更松。')
point(s,3.9,'常见受累结构：外侧韧带','以距腓前韧带损伤最为常见。')
point(s,5.4,'结构受损，稳定性可能下降','随后还需要观察功能如何变化。')
finish(s,'跖屈位内翻，为什么容易伤到外侧？',85,'按照教材顺序，先看损伤机制。我们先找到腓骨远端、距骨和踝关节的位置。踝关节内翻扭伤较为常见，外侧韧带是容易受累的结构，其中又以距腓前韧带为主。为什么教材特别指出跖屈位？因为距骨前宽后窄，跖屈时进入踝穴的后部较窄，关节相对更松，此时再出现内翻应力，就容易发生损伤。这里要把姿势、受力和结构联系起来，而不是只记住一个韧带名称。图中呈现的是骨性位置关系，外侧韧带的名称根据教材讲解，不把骨性插图当作韧带本身。理解这一机制，也就能理解为什么落地、踩到他人足部或突然变向值得关注。','教材第164页：（一）损伤机制。医学插图：https://commons.wikimedia.org/wiki/File:Blausen_0411_FootAnatomy_zh.png ，BruceBlaus／GnolizX，CC BY 3.0；裁取踝部。')
# 4 — textbook functional deficits.
s=base('教材中的功能障碍，不只是疼痛','功能障碍')
photo(s,'training_photos.png',.65,2.25,5.8,4.35,(0,0,.5,.5));text(s,.75,6.43,5.2,.25,'AI训练情境图',11,GREY)
point(s,2.38,'急性表现','疼痛、肿胀、活动度受限，影响负重行走。')
point(s,3.88,'部分患者的持续问题','反复扭伤、不稳定感，活动后酸痛或酸胀。')
point(s,5.38,'需要关注的功能变化','本体感觉缺失、平衡能力下降。')
finish(s,'教材中的功能障碍，不只是疼痛',90,'再看教材的主要功能障碍。急性期常见疼痛、肿胀和活动度受限，影响负重行走。大部分患者通过适当康复可以恢复，但教材也明确指出，部分人会发展为习惯性崴脚，并出现本体感觉缺失和平衡能力下降。注意这里说的是部分患者，并不是每次扭伤都会形成慢性不稳。因此，疼痛减轻只说明一个方面正在改善，不能替代对稳定性和活动能力的观察。教材提到的行走不平地面时不稳，就是很容易理解的例子。因为地面不断变化，我们需要不断调整足踝的控制。接下来要回答的就是：身体依靠什么信息作出这些调整？','教材第165页：（三）主要功能障碍。图片为AI生成训练情境。')
# 5 — one focal concept, visually supported by real-looking photography.
s=base('本体感觉：不看脚，也能感知它的位置与运动','核心知识')
photo(s,'training_photos.png',.65,2.25,5.8,4.35,(.5,0,1,.5));text(s,.75,6.43,5.2,.25,'AI训练情境图',11,GREY)
text(s,7.1,2.38,5.5,.6,'感知关节位置、运动与用力',25,DEEP,True)
text(s,7.1,3.22,5.4,1.1,'肌肉、肌腱、关节等组织\n提供与身体状态有关的信息。',22)
text(s,7.1,4.65,5.5,1.25,'感觉信息与神经系统的整合\n共同支持肌肉反应和姿势调整。',22)
text(s,7.1,6.0,5.5,.45,'本体感觉是平衡控制的重要组成。',21,DEEP,True)
finish(s,'本体感觉：不看脚，也能感知它的位置与运动',100,'本体感觉，可以理解为感知身体部位的位置、运动和用力的能力。我们坐着时不看自己的脚，通常也能知道它是在抬起还是放下，这就有本体感觉的参与。这些信息来自肌肉、肌腱、关节等组织，再由神经系统与其他信息共同整合，组织肌肉活动。放到运动中，足踝状态发生变化，我们需要感知变化，并作出适当调整。若扭伤后相关感觉运动功能受到影响，就可能出现站不稳、调整不及时或运动时不放心等表现。但本体感觉和平衡不能画等号：视觉、前庭功能、力量、注意等也参与平衡。我们的理解应当是，感觉提供信息，神经系统组织反应，肌肉执行控制；其中任何一个环节，都值得在功能评估中关注。','教材第165页有关本体感觉缺失及平衡下降；机制解释为运动控制基础知识。JOSPT 2021踝扭伤临床实践指南，doi:10.2519/jospt.2021.0302。图片为AI生成训练情境。')
# 6 — photo-based observation, no invented diagnostic cutoff.
s=base('看功能：从“站得住”到“动得稳”','功能观察')
photo(s,'training_photos.png',.65,2.28,3.0,3.7,(0,0,.5,.5));photo(s,'training_photos.png',3.85,2.28,3.0,3.7,(.5,0,1,.5))
text(s,.85,6.15,2.65,.4,'单脚支撑',21,DEEP,True,PP_ALIGN.CENTER);text(s,3.95,6.15,2.8,.4,'支撑中移动',21,DEEP,True,PP_ALIGN.CENTER)
text(s,7.35,2.38,5.1,.55,'关注三个问题',25,DEEP,True)
text(s,7.35,3.2,5.1,2.7,'支撑是否稳定？\n移动时能否保持控制？\n是否出现疼痛、不稳或明显代偿？',24)
text(s,7.35,6.0,5.1,.5,'双侧比较，结合多项评估。',21,DEEP,True)
text(s,.72,6.58,6.1,.2,'AI训练情境图；扶稳条件依据个体能力选择。',10,GREY)
finish(s,'看功能：从“站得住”到“动得稳”',85,'因此，观察功能不能停留在能不能走路。先看相对简单的单脚支撑，再看支撑条件下另一侧下肢移动时能否保持控制。观察重点不是单纯坚持多少秒，而是躯干与下肢的控制、是否反复失去平衡，以及是否出现疼痛、不稳或明显代偿。可以结合双侧表现和重复观察了解变化。这里展示的是功能观察与训练任务的例子，不是给出单一诊断标准。单脚站立表现受到多个系统影响，也不能单凭这一项测出本体感觉的全部能力，更不能据此独立决定能否重返运动。教学上我们要建立的认识是：运动要求不同，功能观察也应逐步接近相应的任务。','教材第165页主要功能障碍；JOSPT 2021，doi:10.2519/jospt.2021.0302。图片为AI生成训练情境，不构成标准化测试图卡。')
# 7 — three photo tasks, kept separate from acute injury management.
s=base('再次损伤预防：让控制能力逐步接近运动要求','预防应用')
for i,(region,head,body) in enumerate([((0,0,.5,.5),'稳住支撑','扶稳条件下练习单脚支撑'),((.5,0,1,.5),'控制移动','支撑中完成伸足、重心转移'),((0,.5,.5,1),'接近运动任务','逐步加入台阶、落地与变向')]):
 x=.65+i*4.18;photo(s,'training_photos.png',x,2.3,3.94,2.72,region);text(s,x,5.25,3.94,.45,head,25,DEEP,True);text(s,x,5.92,3.94,.7,body,20)
text(s,.68,6.64,11.9,.22,'AI训练情境图；在损伤处理与评估后，依据症状反应和动作质量逐级安排。',11,GREY)
finish(s,'再次损伤预防：让控制能力逐步接近运动要求',100,'预防如何落地？重点不是找一个神奇动作，而是把任务逐步接近运动要求。在损伤得到适当处理、完成评估后，可以从有扶持条件的单脚支撑开始；随后在支撑中加入伸足和重心转移；再依据恢复情况，逐步接近台阶下步、落地、跑跳和变向。进阶的依据是症状反应、动作质量和任务完成情况，不是简单到了第几天。临床实践指南支持在评估基础上采用本体感觉、平衡和神经肌肉训练以降低再次损伤风险。必要时也可结合护踝等外部支持。这里要强调，本体感觉训练是预防的一部分，不能替代力量、活动度、负荷安排和运动环境管理。对足球而言，最终需要把控制带回变向和对抗情境；对其他运动，则对应各自的任务要求。','JOSPT 2021：再次踝扭伤的二级预防及治疗性运动建议，doi:10.2519/jospt.2021.0302。图片为AI生成训练情境，非统一训练处方。')
# 8 — actual reported role, no fabricated data or outcomes.
s=base('从青少年足球损伤研究，到课堂中的预防意识','研究与实践')
photo(s,'training_photos.png',.65,2.28,5.8,4.15,(.5,.5,1,1));text(s,.73,6.51,5.6,.25,'AI训练情境图（非项目现场照片）',11,GREY)
text(s,7.1,2.35,5.5,.45,'参与项目',22,DEEP,True)
text(s,7.1,3.05,5.5,1.1,'初中阶段足球运动中外侧踝扭伤的风险因素探究',23,DEEP,True)
text(s,7.1,4.35,5.4,1.6,'整理相关研究资料与数据\n梳理外侧踝扭伤风险因素\n归纳分析结果，支持预防研究',22)
text(s,7.1,6.05,5.5,.5,'关注损伤发生，也关注功能恢复。',22,DEEP,True)
finish(s,'从青少年足球损伤研究，到课堂中的预防意识',50,'我在博士阶段参与过初中阶段足球运动中外侧踝扭伤风险因素的相关研究，主要承担研究资料与数据整理分析、风险因素信息梳理和分析结果归纳。这里我想把研究关注转化为课堂中的预防意识：既要关注损伤是否发生，也要关注损伤后的功能恢复。今天讨论的本体感觉与运动控制，是连接教材功能障碍和预防实践的一个切入点。项目参与并不等同于已经证明某一个因素导致损伤，因此在教学中，我会把已有依据、相关线索和具体训练安排区分清楚。','项目名称与参与工作依据用户提供《谢淘简历(3).pdf》科研经历项目3。不展示样本、效果量或研究结果数据；不将项目解释为已经验证本体感觉训练效果。图片为AI生成情境，非项目实录。')
# 9 — functional return, consensus rather than numerical thresholds.
s=base('重返运动，不能只问“还疼不疼”','综合判断')
photo(s,'football_hero.png',.65,2.28,5.8,4.2);text(s,.73,6.5,5.6,.25,'AI训练情境图',11,GREY)
for i,(a,b) in enumerate([('疼痛反应','运动中及运动后的症状变化'),('踝部功能','活动度、力量与耐力'),('主观感受','稳定感、信心与准备程度'),('感觉运动控制','本体感觉与动态平衡'),('运动表现','跑跳、变向与完整训练的完成情况')]):
 y=2.28+i*.79;text(s,7.1,y,5.4,.36,a,21,DEEP,True);text(s,7.1,y+.38,5.4,.36,b,19)
finish(s,'重返运动，不能只问“还疼不疼”',80,'现在回到开场的问题。要判断能否重返运动，除了疼痛，还应当看哪些方面？国际共识提出，需要综合考虑疼痛反应，踝部活动度、力量等功能，运动者的稳定感和准备程度，感觉运动控制，以及运动任务的完成情况。今天的本体感觉就处于感觉运动控制这一部分。它重要，但不是唯一条件。对于一名足球运动者，平地走路没有疼痛，与完成落地、变向乃至一整堂训练，要求显然不同。因此，我不会仅凭不痛或某一项平衡表现就宣布恢复，而是把症状、功能、信心和实际任务结合起来判断。这也是从损伤治疗走向再次损伤预防的关键。','Smith等，2021，PAASS重返运动国际多学科共识。doi:10.1136/bjsports-2021-104087。框架提出应评估的领域，不提供单一通用通过阈值。图片为AI生成正常训练情境。')
# 10 — close with teaching content rather than production notes.
s=p.slides.add_slide(p.slide_layouts[6]);rect(s,0,0,13.333,7.5,DEEP)
text(s,.75,.65,11.8,.5,'回到最初的问题',22,WHITE)
text(s,.75,1.75,11.8,1.2,'不痛了，为什么还会再次扭伤？',35,WHITE,True)
text(s,.8,3.5,11.65,1.5,'疼痛缓解，不等于感觉运动功能充分恢复。\n预防再次损伤，要让功能逐步接近运动要求。',29,WHITE,True)
text(s,.8,6.0,11.4,.6,'课后练习：解释“站得稳”和“动得稳”之间的区别。',23,WHITE)
finish(s,'疼痛缓解，不等于感觉运动功能充分恢复',40,'同学们，现在我们可以回答开场的问题了。疼痛缓解，不等于感觉运动功能已经充分恢复。教材让我们看到踝扭伤后的疼痛、活动受限以及部分患者出现的本体感觉和平衡问题；预防实践则要求我们依据评估，把训练从稳定支撑逐步带回动态运动。请大家记住，不仅看站得稳，也要看动得稳。课后请用一个自己熟悉的运动动作，解释静态稳定和动态控制有什么不同。今天的内容就到这里，谢谢大家。','教材第164—165页；JOSPT 2021临床实践指南；PAASS 2021共识。')
# 11 — optional reference appendix.
s=base('参考资料','参考文献')
text(s,.75,2.25,11.9,3.85,'1  《运动康复评定学》：踝关节损伤，第164—165页。\n\n2  Martin 等，2021：外侧踝韧带扭伤临床实践指南。\n    J Orthop Sports Phys Ther. 51(4): CPG1–CPG80.\n    DOI：10.2519/jospt.2021.0302\n\n3  Smith 等，2021：踝扭伤后重返运动的 PAASS 国际共识。\n    Br J Sports Med. 55:1270–1276. DOI：10.1136/bjsports-2021-104087',20)
text(s,.8,6.38,11.8,.3,'图片：真实比赛研究图帧、中文三维医学插图及AI情境图；完整来源见演讲者备注。',13,GREY)
finish(s,'参考资料',0,'本页为参考资料备查，不占主要讲解时间。正文保持教材机制与功能障碍的顺序，预防与重返运动部分引用临床实践指南和国际共识。项目页仅呈现参与工作，不报告研究数据或推断未验证结论。','教材文件：用户上传《运动康复评定学-踝关节损伤.pdf》。https://doi.org/10.2519/jospt.2021.0302 ；https://doi.org/10.1136/bjsports-2021-104087 。真实图帧：https://pmc.ncbi.nlm.nih.gov/articles/PMC12582226/ ，CC BY 4.0；三维医学图：https://commons.wikimedia.org/wiki/File:Blausen_0411_FootAnatomy_zh.png ，BruceBlaus/GnolizX，CC BY 3.0（局部裁取）。AI图不代表真实参与者或项目实录。')
p.save(ROOT/'Ankle_Proprioception_Interview.pptx')
(ROOT/'逐页讲稿.md').write_text('# 踝关节扭伤后的本体感觉与再损伤预防\n\n主讲：谢淘\n\n'+f'建议总时长：{sum(r["seconds"] for r in records)//60}分{sum(r["seconds"] for r in records)%60}秒（参考页不计）\n\n'+'\n\n'.join(f'## 第{r["slide"]}页 {r["title"]}\n\n参考时长：{r["seconds"]}秒\n\n{r["script"]}\n\n资料：{r["source"]}' for r in records))
(ROOT/'教材与来源核对.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
d=Document();sec=d.sections[0];sec.header.paragraphs[0].text='谢淘｜运动损伤与预防试讲';sty=d.styles['Normal'];sty.font.name='Noto Sans CJK SC';sty.font.size=DPt(11)
d.add_heading('不痛了，为什么还会再次扭伤？',0);d.add_paragraph('踝关节扭伤后的本体感觉与再损伤预防\n主讲：谢淘｜约12分钟')
for r in records:
 d.add_heading(f'{r["slide"]:02} {r["title"]}',1);d.add_paragraph(r['script']);d.add_paragraph('参考时长：'+str(r['seconds'])+'秒')
d.save(ROOT/'谢淘_踝扭伤试讲逐字稿.docx')
print('Slides',len(p.slides),'seconds',sum(r['seconds'] for r in records),'script_chars',sum(len(r['script']) for r in records))
