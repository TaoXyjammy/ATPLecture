from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN
from copy import deepcopy
from pathlib import Path
import json, shutil, io
ROOT=Path(__file__).resolve().parent.parent
TEMPLATE=Path(__file__).parent/'肌骨概述.pptx'
p=Presentation(str(TEMPLATE)); cover=[deepcopy(s._element) for i,s in enumerate(p.slides[0].shapes) if i in [0,4,5]]
cover_pics=[(s.image.blob,s.left,s.top,s.width,s.height) for i,s in enumerate(p.slides[0].shapes) if i in [1,3]]
# The original cover's geometric background and title bracket are retained.
for sid in list(p.slides._sldIdLst):
 p.part.drop_rel(sid.rId);p.slides._sldIdLst.remove(sid)
W,H=13.3333,7.5
RED='FF4726'; ORANGE='F87931'; DARK='263442'; GREY='667381'; LIGHT='FFF2EC'; BLUE='47678E'
records=[]
def shape(s,x,y,w,h,fill,line=None,kind=MSO_SHAPE.RECTANGLE):
 o=s.shapes.add_shape(kind,Inches(x),Inches(y),Inches(w),Inches(h));o.fill.solid();o.fill.fore_color.rgb=RGBColor.from_string(fill);o.line.fill.background() if not line else None
 if line:o.line.color.rgb=RGBColor.from_string(line)
 return o
def text(s,x,y,w,h,t,size=22,color=DARK,bold=False,align=None):
 o=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=o.text_frame;tf.word_wrap=True;tf.margin_left=tf.margin_right=Inches(.04);tf.margin_top=Inches(.02);tf.margin_bottom=0
 for j,l in enumerate(t.split('\n')):
  z=tf.paragraphs[0] if j==0 else tf.add_paragraph();z.text=l;z.font.name='Noto Sans CJK SC';z.font.size=Pt(size);z.font.bold=bold;z.font.color.rgb=RGBColor.from_string(color);z.space_after=Pt(10)
  if align is not None:z.alignment=align
 return o
def line(s,x,y,xx,yy,color=RED,width=2):
 o=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x),Inches(y),Inches(xx),Inches(yy));o.line.color.rgb=RGBColor.from_string(color);o.line.width=Pt(width);return o
def arrow(s,x,y,w=.5,h=.28):return shape(s,x,y,w,h,RED,kind=MSO_SHAPE.RIGHT_ARROW)
def card(s,x,y,w,h,title,body):
 shape(s,x,y,w,h,'F6F7F9');shape(s,x,y,.055,h,RED);text(s,x+.18,y+.14,w-.35,.45,title,23,RED,True);text(s,x+.18,y+.78,w-.35,h-.87,body,21)
def new(title,section,page,note,mode='normal'):
 s=p.slides.add_slide(p.slide_layouts[6])
 # Use template master/theme; rebuild Chinese headers to replace raster English logo.
 s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor(255,255,255)
 shape(s,0,7.14,W,.07,RED)
 text(s,.42,.15,3.5,.4,'康复医学 · 课堂教学',16,ORANGE,True)
 shape(s,0,.72,4.7,.37,RED);text(s,.3,.735,4.2,.32,section,13,'FFFFFF',True)
 text(s,.65,1.25,12,.65,title,30,DARK,True)
 line(s,5.25,1.09,12.85,1.09,'FFB19F',1)
 text(s,.65,6.82,11,.23,'第二章  疼痛的运动康复评定  ·  '+page,10,GREY)
 text(s,12.1,6.78,.6,.3,f'{len(records)+1:02}',12,RED,True)
 s.notes_slide.notes_text_frame.text=note+'\n\n内容依据：用户提供《疼痛.pdf》，'+page+'。图示均为可编辑教学示意；不替代临床诊断。'
 records.append(dict(slide=len(records)+1,title=title,section=section,source=page,note=note))
 return s
def two(title,section,page,a,b,note):
 s=new(title,section,page,note);card(s,.7,2.2,5.8,3.9,*a);card(s,6.8,2.2,5.8,3.9,*b);return s
def steps(s,items,y=2.55):
 n=len(items);w=(11.9-(n-1)*.35)/n
 for i,(a,b) in enumerate(items):
  x=.7+i*(w+.35);card(s,x,y,w,2.85,a,b)
  if i<n-1:arrow(s,x+w+.04,y+1.2,.27,.2)

def body_map(sl,x,y,scale=1.,back=False,mark=False):
    # Outline is designed in a 100x220 coordinate space; right/left are the person's sides.
    points=[(43,29),(43,38),(35,40),(26,43),(22,52),(18,75),(12,97),(10,111),(14,117),(19,113),(22,98),(28,79),(31,64),(33,94),(30,119),(32,147),(35,173),(33,201),(28,212),(41,214),(46,208),(46,180),(48,153),(50,135),(52,153),(54,180),(54,208),(59,214),(72,212),(67,201),(65,173),(68,147),(70,119),(67,94),(69,64),(72,79),(78,98),(81,113),(86,117),(90,111),(88,97),(82,75),(78,52),(74,43),(65,40),(57,38),(57,29)]
    unit=Inches(.019*scale)
    b=sl.shapes.build_freeform(points[0][0],points[0][1],scale=unit)
    b.add_line_segments(points[1:],close=True)
    o=b.convert_to_shape(Inches(x),Inches(y));o.fill.solid();o.fill.fore_color.rgb=RGBColor.from_string('D8E0E8');o.line.fill.background()
    shape(sl,x+.019*scale*38,y+.019*scale*2,.019*scale*24,.019*scale*29,'D8E0E8',kind=MSO_SHAPE.OVAL)
    if back:
        line(sl,x+.95*scale,y+.85*scale,x+.95*scale,y+2.15*scale,'A4B3C1',1)
    if mark:
        shape(sl,x+.019*scale*34,y+.019*scale*151,.019*scale*13,.019*scale*13,RED,kind=MSO_SHAPE.OVAL)
    text(sl,x,y+4.16*scale,1.9*scale,.4,'背面' if back else '正面',17,GREY,False,PP_ALIGN.CENTER)

def assess(sl,lefttitle,leftbody,righttitle,rightbody):
    card(sl,.7,2.15,5.85,4.12,lefttitle,leftbody)
    card(sl,6.8,2.15,5.8,4.12,righttitle,rightbody)

# 1 cover
s=p.slides.add_slide(p.slide_layouts[6])
for el in cover:s.shapes._spTree.insert_element_before(deepcopy(el),'p:extLst')
for blob,x,y,w,h in cover_pics:s.shapes.add_picture(io.BytesIO(blob),x,y,w,h)
# Restore the template bottom rule above the pictures.
shape(s,0,7.13,W,.37,RED)
text(s,.45,.25,5,.5,'康复医学 · 运动康复评定学',22,RED,True)
text(s,3.55,2.2,8.7,.55,'第二章',26,ORANGE,True)
text(s,3.55,2.95,9.1,1.2,'疼痛的运动康复评定',36,RED,True)
text(s,3.6,4.3,8.6,.9,'从主观感受到结构化记录\n疼痛概述  /  疼痛评定方法',22,GREY)
s.notes_slide.notes_text_frame.text='今天学习第二章。我们不只记录痛不痛，还要知道疼痛在哪里、是什么感觉、怎样变化，以及它如何影响运动。'
records.append(dict(slide=1,title='第二章 疼痛的运动康复评定',section='封面',source='章首页',note=s.notes_slide.notes_text_frame.text))
s=new('学习目标与课堂路线','学习目标','章首页','按教材教学提示，重点掌握定义、评定方法与流程，熟悉疼痛分类。先建立概念，再学习如何问、如何量、如何记录。')
steps(s,[('理解疼痛','认识疼痛的主观性\n熟悉疼痛分类'),('完成评定','依次采集病史、部位、性质\n选择合适的评分方法'),('形成记录','追踪疼痛变化\n按 SAND 汇总结果')])
s=new('同样是4分疼痛，评定结论会一样吗？','案例导入','教学案例 · 对接第15页','借鉴PEARS从生活体验进入疼痛认识的表达方式，改编为两个虚构的普通运动参与者。两人都在下楼时自评4/10，但活动影响、情绪、睡眠可能不同。请学生先列出还要问什么，不在导入阶段诊断或给出治疗方案。随后回到教材第一节。')
assess(s,'甲：运动后右膝酸痛','两周前开始，无明确单次外伤\n下楼时自评4/10\n仍能完成日常步行\n想知道怎样安排后续活动','乙：也说“下楼痛4分”','已经担心到不愿出门\n睡眠受到影响\n害怕活动会进一步损伤膝关节\n想知道疼痛是不是等于损伤加重')
text(s,.9,6.42,11.6,.35,'先讨论：除分值外，还要了解部位、性质、变化与生活影响。',18,RED,True)
two('疼痛评估：评什么，为什么评？','第一节  疼痛概述','第15页',('疼痛是一种个人体验','感觉与情绪相互关联\n受到身体、心理和社会因素影响\n应尊重患者对疼痛的描述'),('评定服务于康复决策','了解疼痛来源与相关因素\n识别日常生活和运动功能的受限\n建立基线，比较康复前后的变化'),'教材先介绍疼痛评估的意义。疼痛评分能记录体验强度，但不能单凭分值确认组织损伤或制定完整方案。')
s=new('疼痛的定义：保留教材框架，补充现行表述','第一节  疼痛概述','第15页；IASP 2020 补充','教材所述定义强调感觉、情绪、认知与社会层面。补充国际疼痛学会2020年修订定义：与实际或潜在组织损伤相关，或类似于这种相关体验的不愉快感觉和情绪体验。疼痛与伤害感受是不同现象，不能仅由感觉神经元活动推断疼痛。')
card(s,.7,2.15,11.9,1.65,'现行定义 · 中文意译','与实际或潜在组织损伤相关，或类似于这种相关体验的不愉快感觉和情绪体验。')
text(s,.9,4.2,11.4,1.5,'① 疼痛与伤害感受不同。\n② 疼痛强度不能直接换算成组织损伤程度。\n③ 既问疼痛，也问活动、睡眠与生活影响。',23)
s=new('疼痛分类①：按教材的类别框架认识','第一节  疼痛概述','第15页','依教材先区分伤害性疼痛与病理性疼痛，再看各自分支。这是教材分类框架，部分术语与现行机制分类不完全一致，不应把功能性疼痛理解成没有真实疼痛。')
card(s,.7,2.2,5.8,3.35,'伤害性疼痛','浅表痛\n深部痛\n关注刺激来源和组织部位')
card(s,6.8,2.2,5.8,3.35,'病理性疼痛（教材用语）','炎症性疼痛\n神经病理性疼痛\n功能性疼痛')
text(s,.85,5.9,11.7,.55,'课堂提示：分类帮助组织线索；实际个体可能存在多种机制。',19,GREY)
two('疼痛分类②：机械刺激与化学刺激','第一节  疼痛概述','第15页',('机械性疼痛','机械应力刺激伤害感受器\n例如：某个动作或受力条件诱发疼痛\n问诊重点：什么动作、负荷和体位？'),('化学性疼痛','组织损伤后相关化学介质参与\n如组胺、缓激肽、白细胞三烯等\n问诊重点：局部反应与持续变化'),'按教材顺序介绍刺激来源。足球变向后疼痛可能伴随机械刺激和炎症反应，不能仅由一个动作把疼痛归入唯一机制。')
two('疼痛分类③：急性与慢性','第一节  疼痛概述','第15—16页',('急性疼痛','教材以持续时间小于3个月区分\n可见于扭伤、骨折、切割伤等\n常提示近期损伤或威胁'),('慢性疼痛','持续或反复超过3个月\n可能超出通常组织愈合时间\n需要同时了解功能、情绪与行为'),'三个月用于课堂区分，恰在边界时结合所用诊断标准。慢性疼痛并不等于损伤一直恶化，也不意味着不能改善。')
s=new('慢性疼痛：从局部症状看到整体功能','第一节  疼痛概述','第15—16页','教材依次列出四方面改变：代谢、运动控制、自主功能及中枢神经系统功能。它们可能相互影响，但并非每个人都出现全部改变。')
steps(s,[('局部组织','局部循环下降\n肿胀、营养改变'),('运动控制','代偿动作\n动作模式改变'),('自主功能','自主反应变化\n肌张力、感觉变化'),('中枢功能','疼痛调节改变\n耐受性变化')])
text(s,.9,5.8,11.6,.6,'观察动作与活动参与：疼痛持续 → 动作改变 → 其他部位负荷改变。',21,RED,True)
s=new('疼痛部位不一定等于疼痛来源','第一节  疼痛概述','第16页','教材指出骨骼肌肉疼痛涉及关节、肌肉和神经系统。患者指出的痛点是评估起点，不是最终病因结论。不要用疼痛大小推断损伤严重程度。')
steps(s,[('可能涉及的结构','关节：包括韧带\n肌肉：包括肌腱和腱膜\n神经系统'),('症状与代偿','疼痛使动作发生改变\n其他部位分担工作负荷\n可能出现新的不适'),('评定的任务','核对症状与动作\n结合病史和检查\n形成可验证的判断')])
s=new('第二节：按教材顺序完成七项评定','第二节  疼痛评定方法','第16—19页','接下来进入评定方法。七项顺序固定，先问诊，再量化，再观察变化，最后整理结果。')
text(s,1.1,2.15,11,4.3,'一  疼痛相关的病史采集\n二  疼痛的部位\n三  疼痛的性质\n四  疼痛程度的评定\n五  疼痛的发展进程\n六  疼痛加重和缓解的因素\n七  疼痛的结果记录',24)
s=new('一、病史采集：先建立完整背景','第二节  疼痛评定方法','第16页','按现病史、既往史、家族史、外科手术史、用药史和吸烟饮酒等习惯提问。示例是教学情境，不是临床个案。')
card(s,.7,2.1,5.85,4.2,'需要了解的内容','现病史：何时开始、怎样发生、如何变化\n既往史、手术史、家族史\n用药情况：是否使用镇痛药及其效果\n吸烟、饮酒等相关生活习惯')
card(s,6.85,2.1,5.75,4.2,'通用提问示例','“第一次疼痛发生在什么情况下？”\n“之前是否有相似的不适？”\n“用了什么处理方法，变化如何？”\n足球可作为变向受伤的情境之一。')
s=new('二、疼痛的部位：身体图与文字相互核对','第二节  疼痛评定方法','第16页','借鉴Symptom-Assesment-Interface的身体定位加文字记录结构，自行重绘可编辑正背面身体轮廓。正面左侧对应患者右侧；图上红点仅代表教学案例甲所述右膝前侧，背面未标记不代表已排除症状。请学生向患者逐项确认，而不是通过图形猜测来源。E为外侧，I为内侧，EI为内外侧，字母不代表左右或深浅。')
shape(s,.7,2.15,5.85,4.35,'F6F7F9')
text(s,.9,2.27,5.45,.45,'案例甲 · 在身体图标记疼痛范围',22,RED,True)
body_map(s,1.2,2.85,.72,False,True);body_map(s,3.78,2.85,.72,True,False)
text(s,.9,6.35,5.4,.28,'正面：图左为患者右侧  ·  红点仅表示报告部位',13,GREY)
card(s,6.8,2.15,5.8,4.35,'右侧文字记录：由患者确认','部位：右膝前侧\n范围：一点，还是一片区域？\n分布：有无向其他部位延伸？\n内外侧：外侧E／内侧I／两侧EI\n深浅：另行询问，归入SAND的D')

two('三、疼痛的性质：先记录患者自己的话','第二节  疼痛评定方法','第16—17页',('描述词汇','钝痛、酸痛、胀痛、闷痛\n刺痛、锐痛、切割痛、灼烧痛\n绞痛、放射痛、牵涉痛'),('描述如何用于判断','麻木、灼烧、针刺样感觉：关注神经线索\n浅表或深部的感觉特点可提供线索\n单个形容词不能确诊组织来源'),'请患者先自由描述，再进一步澄清。教材列举性质与结构之间的常见联系，但不能当作一一对应的诊断规则。')
two('分清牵涉痛与放射痛','第二节  疼痛评定方法','第17页',('牵涉痛','感觉到疼痛的位置与实际来源不同\n教材示例：某些上肢疼痛可能与斜角肌相关\n需要结合其他检查确认来源'),('放射痛','疼痛沿一定路径向远端延伸\n教材示例：腰部问题伴臀部、下肢症状\n需结合神经系统检查判断'),'重点不是背诵病名，而是问清是否沿路径延伸、是否伴麻木无力，以及疼痛位置与诱发条件。')
s=new('四、疼痛程度：四种方法依次学习','第二节  疼痛评定方法','第17页','教材的顺序是VAS、NRS、VRS、FPS。四种方法都是了解体验强度的工具，选择时考虑理解和表达能力。复测尽量保持同一工具、同一条件。')
steps(s,[('① 视觉模拟','VAS\n在线段上标记'),('② 数字评分','NRS\n选择0—10的数字'),('③ 口述分级','VRS\n选择描述词'),('④ 面部表情','FPS\n选择相应面孔')])
text(s,.9,5.8,11.6,.6,'先固定条件：现在，还是过去一周？静息，还是完成某个活动时？',21,RED,True)
s=new('（一）视觉模拟评分法：VAS','第二节  疼痛评定方法','第17页','参考第1项网页版幻灯片的左右分栏：左呈现工具，右呈现执行步骤。使用纸面真实10厘米线段，患者标记后测量距无痛端距离。教材建议评估2次取平均值。投影线段只作示意，不作为实际测量工具。')
shape(s,.7,2.15,5.85,4.15,'F6F7F9');text(s,.9,2.3,5.45,.45,'左：工具示意与测量',22,RED,True)
line(s,1.1,3.65,6.15,3.65,DARK,3)
for x in [1.1,6.15]:line(s,x,3.5,x,3.8,DARK)
line(s,2.87,3.4,2.87,3.9,RED,3);text(s,2.1,2.95,3,.45,'患者自行标记',21,RED)
text(s,1,4.0,2,.45,'无痛（0）',20);text(s,4.5,4.0,2,.45,'极痛（100）',20)
text(s,1,4.85,5.15,1.1,'纸面实际长度：10厘米\n距左端35毫米 → 记录35/100\n屏幕线段仅为教学示意。',20)
card(s,6.8,2.15,5.8,4.15,'右：怎样说明与记录','① 确认患者理解两端的含义\n② 请患者独立标记疼痛位置\n③ 测量距无痛端的毫米数\n④ 记录时间、活动条件和结果\n同一工具、同一条件进行复测。')

s=new('（二）数字评分法：NRS','第二节  疼痛评定方法','第17页','让受评者从0到10选择最符合其感受的数字。左边为教学选择示例4，右边以案例甲说明时间、活动和分值的完整记录。不能把4分等同于某一种损伤严重程度，也不固定划分轻中重阈值。')
shape(s,.7,2.15,5.85,4.15,'F6F7F9');text(s,.9,2.3,5.45,.45,'左：选择一个最符合感受的数字',21,RED,True)
for i in range(11):
 x=1.02+(i%6)*.86;y=3.16+(i//6)*.85
 shape(s,x,y,.68,.64,RED if i==4 else 'FFFFFF',kind=MSO_SHAPE.ROUNDED_RECTANGLE)
 text(s,x,y+.07,.68,.45,str(i),22,'FFFFFF' if i==4 else DARK,True,PP_ALIGN.CENTER)
text(s,1,5.1,5.1,.9,'0＝无痛\n10＝最剧烈的疼痛',21)
card(s,6.8,2.15,5.8,4.15,'右：让分数具有可比较的含义','先问：现在，还是过去一周？\n再问：静息，还是完成某个活动时？\n案例甲：今日下楼时4/10；静息1/10\n另记：上下楼活动受到影响\n随访时保持活动与评估条件一致。')

s=new('（三）口述分级评分法：VRS','第二节  疼痛评定方法','第17页','左边按教材从无痛到无法忍受排列描述词，右边说明操作方式。请患者自己选择；如词语含义不清，先澄清理解，不要暗示答案。描述词与数字分值没有可随意套用的固定换算。')
shape(s,.7,2.15,5.85,4.15,'F6F7F9');text(s,.9,2.3,5.45,.45,'左：按疼痛强弱排列的描述词',22,RED,True)
for i,a in enumerate(['无痛','轻度疼痛','中度疼痛','重度疼痛','剧烈疼痛','无法忍受']):
 x=1.0+(i%2)*2.65;y=3.05+(i//2)*.9
 shape(s,x,y,2.4,.68,'FFF2EC');text(s,x,y+.1,2.4,.45,a,21,RED,True,PP_ALIGN.CENTER)
card(s,6.8,2.15,5.8,4.15,'右：说明、选择、记录','说明：这些词依疼痛强弱排列\n选择：哪一项最接近你的感受？\n记录：原词语＋时间＋活动条件\n复测：沿用同一套词语与提问方式\n不要自行转换成固定NRS分值。')

s=new('（四）面部表情评分法：FPS','第二节  疼痛评定方法','第17页','此页延续第1项的工具选择和操作要点分栏。教材介绍六种表情组成的方法，常用于儿童等人群。正式使用必须采用适龄且经验证量表的原版图卡与指导语。此页不将自绘表情冒充标准量表，不照搬参考课件的固定年龄界限。')
assess(s,'左：什么情况下考虑使用？','适合能够理解面孔含义的受评者\n考虑年龄、理解与沟通能力\n选择适合人群的正式量表版本\n面孔帮助表达疼痛强度','右：怎样完成评定？','使用该版本标准图卡和指导语\n由受评者选择代表自己疼痛的面孔\n按该版本规则计分并记录名称\n复测保持同一版本和相同条件')
text(s,.9,6.42,11.6,.35,'评的是疼痛程度，不是开心或伤心；观察表情不能替代患者选择。',18,RED,True)

s=new('四种评分方法如何选择？','第二节  疼痛评定方法','第17页 · 教学归纳','这是对前面四种方法的归纳，不改变教材章节顺序。能理解数字者可用NRS，能理解连续线段者可用VAS，偏好语言描述者可选VRS，合适的儿童群体可用经验证FPS版本。')
rows=[('VAS','连续线段标记','理解端点并完成线段定位'),('NRS','0—10数字选择','理解数字及其强弱含义'),('VRS','描述词语选择','理解分级词汇'),('FPS','标准面孔选择','使用适龄版本和标准指导语')]
for i,(a,b,c) in enumerate(rows):
 y=2.15+i*.9;shape(s,.8,y,11.7,.78,'F6F7F9' if i%2==0 else LIGHT);text(s,1,y+.15,1.2,.5,a,22,RED,True);text(s,2.55,y+.15,3.4,.5,b,22);text(s,6.25,y+.15,5.9,.5,c,21)
text(s,1,6.15,11.4,.4,'连续随访：优先保持工具、活动任务和评估时点一致。',20,RED,True)
s=new('五、疼痛的发展进程：先问时间，再看变化','第二节  疼痛评定方法','第18页','左列保持教材五方面提问：持续或间断、活动前中后、晨起夜间或一天结束、急慢性及功能、处理后变化。右列继续案例甲。时间规律是线索，不能仅凭夜间疼痛或活动变化推断病因。')
assess(s,'左：按时间顺序追问','持续还是间断？\n活动前、活动中、活动后如何？\n晨起、夜间、一天结束有何变化？\n持续多久，伴什么功能障碍？\n接受过什么处理，处理后如何？','右：案例甲的后续信息','两周前开始，无明确单次外伤\n重复下楼时出现酸痛\n静息后减轻，平地步行尚可\n是否晨起痛、夜间痛仍需追问\n记录已知信息，也记录尚未确认项。')

s=new('六、疼痛加重和缓解的因素','第二节  疼痛评定方法','第18页','依教材了解体位、姿势和动作的影响。对于激惹性较高者，评估中避免反复诱发明显症状。除身体因素外，也需了解情绪、注意、经历和康复需求。')
card(s,.7,2.15,5.8,3.95,'活动与姿势','哪些动作会加重？\n哪些姿势或活动会缓解？\n停止活动后多久恢复？\n是否影响正常行走、上下楼或睡眠？')
card(s,6.8,2.15,5.8,3.95,'个体与环境','年龄、情绪与注意力\n既往疼痛经历与个人特点\n社会文化背景与当前需求\n结合多方面信息制定康复方案')
s=new('七、疼痛的结果记录：用 SAND 汇总','第二节  疼痛评定方法','第18—19页','教材SAND四项含义保持不变：S严重程度，A部位，N性质及持续或间断，D深度。D是depth，不是duration。右侧把案例甲的信息归入对应项目，另行保留完整病史、进程及影响因素。')
assess(s,'左：四项记录内容','S｜严重程度：量表、分值、条件\nA｜部位：位置与范围\nN｜性质：感觉描述、持续或间断\nD｜深度：表浅或深部','右：案例甲的记录示例','S｜今日下楼NRS 4/10；静息1/10\nA｜右膝前侧，见身体图红点\nN｜酸痛，间断出现\nD｜自述深部，定位不十分清晰')
text(s,.9,6.42,11.6,.35,'SAND 是结果摘要；病史、发展进程和加重缓解因素仍须单独保留。',18,RED,True)

s=new('回到案例甲：评定结果怎样支持后续检查？','第二节  疼痛评定方法','第18—19页 · 教学案例','情境为虚构的教学案例。学生参加一次跑跳活动后膝部不适，也可换成足球训练。强调描述与诊断分开，不能用这一记录直接确认损伤。')
card(s,.7,2.1,5.8,4.35,'SAND 核心记录','S：今日下楼时 NRS 4/10，静息1/10\nA：右膝前侧，已在身体图标记\nN：酸痛，间断出现\nD：自述深部，定位不十分清晰')
card(s,6.8,2.1,5.8,4.35,'下一步还要了解什么？','两周前开始，无明确单次外伤\n下楼、重复蹲起时加重，休息减轻\n晨起、夜间变化与既往处理待确认\n结合体格检查与功能评定核对假设')
s=new('课堂练习：你还需要追问什么？','课堂应用','第19页思考题 · 教学案例','给学生一分钟列追问，再按病史、部位、性质、程度、进程、影响因素、结果记录核对。答案在讲解备注中，不要在投影上立即展示。参考：何时开始；位置范围深度；性质；具体时段和活动；量表与条件；加重缓解；既往史与处理；功能影响。')
card(s,.8,2.2,11.7,1.7,'来访者的描述','“我最近运动后脚踝不舒服，休息会好一些，但不知道算不算严重。”')
text(s,1.05,4.35,11.2,1.8,'① 按教材七项顺序提出追问。\n② 选择一种评分工具，说明评估条件。\n③ 还缺少哪些信息，才能形成 SAND 记录？',25)
s=new('回到教材的三道思考题','复习与讨论','第19页','参考答案：VAS需解释两端含义、10厘米线标记、测距并记录条件；评定内容为第二节七项；SAND依次严重程度、部位、性质、深度。提醒学生疼痛分数只是评定的一部分。')
text(s,1.05,2.3,11.3,3.6,'1. 如何使用 VAS 方法评定疼痛？\n2. 疼痛评定包括哪些内容？\n3. SAND 分别记录什么？',29)
text(s,1.05,5.65,11.3,.8,'疼痛评定的目标：理解个体体验，识别功能影响，形成可比较的记录。',23,RED,True)
s=new('教材与补充资料','参考资料','第15—19页及章首页','主要内容来自用户提供的第二章教材扫描件，顺序与教材一致。IASP定义和VAS资料仅作更新与操作补充。模板来自用户提供肌骨概述PPTX，图片和文字结构并未作为疼痛知识来源。')
text(s,.9,2.1,11.7,3.9,'主要依据\n《运动康复评定学》第二章“疼痛的运动康复评定”，用户提供扫描件，章首页及第15—19页。\n\n补充资料\n国际疼痛学会（IASP）：2020年修订疼痛定义及相关说明。\nNSW Agency for Clinical Innovation：视觉模拟评分法操作资料。\n\n模板：《肌骨概述.pptx》（用户提供）。',20)
s=new('本版借鉴了哪些教学呈现方式？','教学设计来源','GitHub参考 · 内容仍以教材为主','仅借鉴组织与呈现思路，未复制他人的图片或页面代码。案例为自行编写，身体图为自行重绘。以下来源不替代教材和专业指南。完整链接见备注及README。')
assess(s,'来源与用途','第1项：评定内容左右分栏\nSleep, Comfort & Pain Management\n第2项：生活情境进入疼痛认识\nPEARS疼痛教育课程\n第5项：身体图配合文字定位','落实到本课件','左侧展示工具，右侧说明操作与记录\n同样4分，功能与生活影响可能不同\n正背面身体图＋右侧中文症状记录\n教材七项评定顺序和SAND保持不变')
s.notes_slide.notes_text_frame.text+='\n\n参考链接：\nhttps://github.com/sagreenxyz/sagreenxyz.github.io2/blob/main/src/pages/private/d439/sleep-comfort-pain-slides.astro\nhttps://github.com/PlymouthPsychology/pears\nhttps://github.com/iamdigiovanni/Symptom-Assesment-Interface\n'
p.save(str(ROOT/'Chapter2_Pain_Assessment_Reference_V2.pptx'))
(ROOT/'顺序核对.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
(ROOT/'逐页讲解备注.md').write_text('# 第二章 疼痛的运动康复评定｜逐页讲解备注\n\n'+ '\n\n'.join(f'## {r["slide"]:02} {r["title"]}\n\n教材位置：{r["source"]}\n\n{r["note"]}' for r in records)+'\n\n参考链接：\n- https://www.iasp-pain.org/publications/iasp-news/iasp-announces-revised-definition-of-pain/\n- https://aci.health.nsw.gov.au/__data/assets/pdf_file/0018/212913/ACI-Pain-assessment-tools-visual-analogue-scale.pdf\n')
print('Built',len(p.slides),'slides')
