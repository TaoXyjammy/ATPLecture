from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN
from copy import deepcopy
from pathlib import Path
import json, shutil, io
ROOT=Path(__file__).resolve().parent.parent
TEMPLATE=Path(__file__).parent/'肌骨概述.pptx'
p=Presentation(str(TEMPLATE)); cover=[deepcopy(s._element) for i,s in enumerate(p.slides[0].shapes) if i in [0,4,5]]
cover_pics=[(s.image.blob,s.left,s.top,s.width,s.height) for i,s in enumerate(p.slides[0].shapes) if i in [1,3]]
# The original cover's geometric background and title bracket are retained.
for sid in list(p.slides._sldIdLst):
 p.part.drop_rel(sid.rId);p.slides._sldIdLst.remove(sid)
W,H=13.3333,7.5
RED='FF4726'; ORANGE='F87931'; DARK='263442'; GREY='667381'; LIGHT='FFF2EC'; BLUE='47678E'
records=[]
def shape(s,x,y,w,h,fill,line=None,kind=MSO_SHAPE.RECTANGLE):
 o=s.shapes.add_shape(kind,Inches(x),Inches(y),Inches(w),Inches(h));o.fill.solid();o.fill.fore_color.rgb=RGBColor.from_string(fill);o.line.fill.background() if not line else None
 if line:o.line.color.rgb=RGBColor.from_string(line)
 return o
def text(s,x,y,w,h,t,size=22,color=DARK,bold=False,align=None):
 o=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=o.text_frame;tf.word_wrap=True;tf.margin_left=tf.margin_right=Inches(.04);tf.margin_top=Inches(.02);tf.margin_bottom=0
 for j,l in enumerate(t.split('\n')):
  z=tf.paragraphs[0] if j==0 else tf.add_paragraph();z.text=l;z.font.name='Noto Sans CJK SC';z.font.size=Pt(size);z.font.bold=bold;z.font.color.rgb=RGBColor.from_string(color);z.space_after=Pt(10)
  if align is not None:z.alignment=align
 return o
def line(s,x,y,xx,yy,color=RED,width=2):
 o=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x),Inches(y),Inches(xx),Inches(yy));o.line.color.rgb=RGBColor.from_string(color);o.line.width=Pt(width);return o
def arrow(s,x,y,w=.5,h=.28):return shape(s,x,y,w,h,RED,kind=MSO_SHAPE.RIGHT_ARROW)
def card(s,x,y,w,h,title,body):
 shape(s,x,y,w,h,'F6F7F9');shape(s,x,y,.055,h,RED);text(s,x+.18,y+.14,w-.35,.45,title,23,RED,True);text(s,x+.18,y+.78,w-.35,h-.87,body,21)
def new(title,section,page,note,mode='normal'):
 s=p.slides.add_slide(p.slide_layouts[6])
 # Use template master/theme; rebuild Chinese headers to replace raster English logo.
 s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor(255,255,255)
 shape(s,0,7.14,W,.07,RED)
 text(s,.42,.15,3.5,.4,'康复医学 · 课堂教学',16,ORANGE,True)
 shape(s,0,.72,4.7,.37,RED);text(s,.3,.735,4.2,.32,section,13,'FFFFFF',True)
 text(s,.65,1.25,12,.65,title,30,DARK,True)
 line(s,5.25,1.09,12.85,1.09,'FFB19F',1)
 text(s,.65,6.82,11,.23,'第二章  疼痛的运动康复评定  ·  '+page,10,GREY)
 text(s,12.1,6.78,.6,.3,f'{len(records)+1:02}',12,RED,True)
 s.notes_slide.notes_text_frame.text=note+'\n\n内容依据：用户提供《疼痛.pdf》，'+page+'。图示均为可编辑教学示意；不替代临床诊断。'
 records.append(dict(slide=len(records)+1,title=title,section=section,source=page,note=note))
 return s
def two(title,section,page,a,b,note):
 s=new(title,section,page,note);card(s,.7,2.2,5.8,3.9,*a);card(s,6.8,2.2,5.8,3.9,*b);return s
def steps(s,items,y=2.55):
 n=len(items);w=(11.9-(n-1)*.35)/n
 for i,(a,b) in enumerate(items):
  x=.7+i*(w+.35);card(s,x,y,w,2.85,a,b)
  if i<n-1:arrow(s,x+w+.04,y+1.2,.27,.2)
# 1 cover
s=p.slides.add_slide(p.slide_layouts[6])
for el in cover:s.shapes._spTree.insert_element_before(deepcopy(el),'p:extLst')
for blob,x,y,w,h in cover_pics:s.shapes.add_picture(io.BytesIO(blob),x,y,w,h)
# Restore the template bottom rule above the pictures.
shape(s,0,7.13,W,.37,RED)
text(s,.45,.25,5,.5,'康复医学 · 运动康复评定学',22,RED,True)
text(s,3.55,2.2,8.7,.55,'第二章',26,ORANGE,True)
text(s,3.55,2.95,9.1,1.2,'疼痛的运动康复评定',36,RED,True)
text(s,3.6,4.3,8.6,.9,'从主观感受到结构化记录\n疼痛概述  /  疼痛评定方法',22,GREY)
s.notes_slide.notes_text_frame.text='今天学习第二章。我们不只记录痛不痛，还要知道疼痛在哪里、是什么感觉、怎样变化，以及它如何影响运动。'
records.append(dict(slide=1,title='第二章 疼痛的运动康复评定',section='封面',source='章首页',note=s.notes_slide.notes_text_frame.text))
s=new('学习目标与课堂路线','学习目标','章首页','按教材教学提示，重点掌握定义、评定方法与流程，熟悉疼痛分类。先建立概念，再学习如何问、如何量、如何记录。')
steps(s,[('理解疼痛','认识疼痛的主观性\n熟悉疼痛分类'),('完成评定','依次采集病史、部位、性质\n选择合适的评分方法'),('形成记录','追踪疼痛变化\n按 SAND 汇总结果')])
two('疼痛评估：评什么，为什么评？','第一节  疼痛概述','第15页',('疼痛是一种个人体验','感觉与情绪相互关联\n受到身体、心理和社会因素影响\n应尊重患者对疼痛的描述'),('评定服务于康复决策','了解疼痛来源与相关因素\n识别日常生活和运动功能的受限\n建立基线，比较康复前后的变化'),'教材先介绍疼痛评估的意义。疼痛评分能记录体验强度，但不能单凭分值确认组织损伤或制定完整方案。')
s=new('疼痛的定义：保留教材框架，补充现行表述','第一节  疼痛概述','第15页；IASP 2020 补充','教材所述定义强调感觉、情绪、认知与社会层面。补充国际疼痛学会2020年修订定义：与实际或潜在组织损伤相关，或类似于这种相关体验的不愉快感觉和情绪体验。疼痛与伤害感受是不同现象，不能仅由感觉神经元活动推断疼痛。')
card(s,.7,2.15,11.9,1.65,'现行定义 · 中文意译','与实际或潜在组织损伤相关，或类似于这种相关体验的不愉快感觉和情绪体验。')
text(s,.9,4.2,11.4,1.5,'① 疼痛与伤害感受不同。\n② 疼痛强度不能直接换算成组织损伤程度。\n③ 既问疼痛，也问活动、睡眠与生活影响。',23)
s=new('疼痛分类①：按教材的类别框架认识','第一节  疼痛概述','第15页','依教材先区分伤害性疼痛与病理性疼痛，再看各自分支。这是教材分类框架，部分术语与现行机制分类不完全一致，不应把功能性疼痛理解成没有真实疼痛。')
card(s,.7,2.2,5.8,3.35,'伤害性疼痛','浅表痛\n深部痛\n关注刺激来源和组织部位')
card(s,6.8,2.2,5.8,3.35,'病理性疼痛（教材用语）','炎症性疼痛\n神经病理性疼痛\n功能性疼痛')
text(s,.85,5.9,11.7,.55,'课堂提示：分类帮助组织线索；实际个体可能存在多种机制。',19,GREY)
two('疼痛分类②：机械刺激与化学刺激','第一节  疼痛概述','第15页',('机械性疼痛','机械应力刺激伤害感受器\n例如：某个动作或受力条件诱发疼痛\n问诊重点：什么动作、负荷和体位？'),('化学性疼痛','组织损伤后相关化学介质参与\n如组胺、缓激肽、白细胞三烯等\n问诊重点：局部反应与持续变化'),'按教材顺序介绍刺激来源。足球变向后疼痛可能伴随机械刺激和炎症反应，不能仅由一个动作把疼痛归入唯一机制。')
two('疼痛分类③：急性与慢性','第一节  疼痛概述','第15—16页',('急性疼痛','教材以持续时间小于3个月区分\n可见于扭伤、骨折、切割伤等\n常提示近期损伤或威胁'),('慢性疼痛','持续或反复超过3个月\n可能超出通常组织愈合时间\n需要同时了解功能、情绪与行为'),'三个月用于课堂区分，恰在边界时结合所用诊断标准。慢性疼痛并不等于损伤一直恶化，也不意味着不能改善。')
s=new('慢性疼痛：从局部症状看到整体功能','第一节  疼痛概述','第15—16页','教材依次列出四方面改变：代谢、运动控制、自主功能及中枢神经系统功能。它们可能相互影响，但并非每个人都出现全部改变。')
steps(s,[('局部组织','局部循环下降\n肿胀、营养改变'),('运动控制','代偿动作\n动作模式改变'),('自主功能','自主反应变化\n肌张力、感觉变化'),('中枢功能','疼痛调节改变\n耐受性变化')])
text(s,.9,5.8,11.6,.6,'观察动作与活动参与：疼痛持续 → 动作改变 → 其他部位负荷改变。',21,RED,True)
s=new('疼痛部位不一定等于疼痛来源','第一节  疼痛概述','第16页','教材指出骨骼肌肉疼痛涉及关节、肌肉和神经系统。患者指出的痛点是评估起点，不是最终病因结论。不要用疼痛大小推断损伤严重程度。')
steps(s,[('可能涉及的结构','关节：包括韧带\n肌肉：包括肌腱和腱膜\n神经系统'),('症状与代偿','疼痛使动作发生改变\n其他部位分担工作负荷\n可能出现新的不适'),('评定的任务','核对症状与动作\n结合病史和检查\n形成可验证的判断')])
s=new('第二节：按教材顺序完成七项评定','第二节  疼痛评定方法','第16—19页','接下来进入评定方法。七项顺序固定，先问诊，再量化，再观察变化，最后整理结果。')
text(s,1.1,2.15,11,4.3,'一  疼痛相关的病史采集\n二  疼痛的部位\n三  疼痛的性质\n四  疼痛程度的评定\n五  疼痛的发展进程\n六  疼痛加重和缓解的因素\n七  疼痛的结果记录',24)
s=new('一、病史采集：先建立完整背景','第二节  疼痛评定方法','第16页','按现病史、既往史、家族史、外科手术史、用药史和吸烟饮酒等习惯提问。示例是教学情境，不是临床个案。')
card(s,.7,2.1,5.85,4.2,'需要了解的内容','现病史：何时开始、怎样发生、如何变化\n既往史、手术史、家族史\n用药情况：是否使用镇痛药及其效果\n吸烟、饮酒等相关生活习惯')
card(s,6.85,2.1,5.75,4.2,'通用提问示例','“第一次疼痛发生在什么情况下？”\n“之前是否有相似的不适？”\n“用了什么处理方法，变化如何？”\n足球可作为变向受伤的情境之一。')
s=new('二、疼痛的部位：让描述落到身体图上','第二节  疼痛评定方法','第16页','让患者指出具体部位，并区分单点或区域、浅表或深部。教材E表示外侧、I表示内侧，均不代表深浅。身体示意图只用于症状定位。')
# Native human schematic for symptom mapping, not a fabricated anatomy plate.
shape(s,2.35,2.1,.62,.62,'D9E0E7',kind=MSO_SHAPE.OVAL);shape(s,2.15,2.85,1.02,1.65,'D9E0E7',kind=MSO_SHAPE.ROUNDED_RECTANGLE)
for x,yy,ww,hh in [(1.65,2.95,.35,1.65),(3.32,2.95,.35,1.65),(2.18,4.55,.38,1.65),(2.77,4.55,.38,1.65)]:shape(s,x,yy,ww,hh,'D9E0E7',kind=MSO_SHAPE.ROUNDED_RECTANGLE)
shape(s,2.83,5.1,.23,.23,RED,kind=MSO_SHAPE.OVAL);line(s,3.08,5.2,4.55,4.95);text(s,3.8,4.4,2,.5,'患者指出的痛点',17,RED)
text(s,1.5,6.3,3.8,.3,'身体定位教学示意',12,GREY)
card(s,6.2,2.1,6.4,4.25,'定位时逐项确认','某一点，还是一个区域？\n表浅，还是深部？\n有无放射、牵涉或其他部位不适？\n外侧记 E，内侧记 I，内外侧均有记 EI。')
two('三、疼痛的性质：先记录患者自己的话','第二节  疼痛评定方法','第16—17页',('描述词汇','钝痛、酸痛、胀痛、闷痛\n刺痛、锐痛、切割痛、灼烧痛\n绞痛、放射痛、牵涉痛'),('描述如何用于判断','麻木、灼烧、针刺样感觉：关注神经线索\n浅表或深部的感觉特点可提供线索\n单个形容词不能确诊组织来源'),'请患者先自由描述，再进一步澄清。教材列举性质与结构之间的常见联系，但不能当作一一对应的诊断规则。')
two('分清牵涉痛与放射痛','第二节  疼痛评定方法','第17页',('牵涉痛','感觉到疼痛的位置与实际来源不同\n教材示例：某些上肢疼痛可能与斜角肌相关\n需要结合其他检查确认来源'),('放射痛','疼痛沿一定路径向远端延伸\n教材示例：腰部问题伴臀部、下肢症状\n需结合神经系统检查判断'),'重点不是背诵病名，而是问清是否沿路径延伸、是否伴麻木无力，以及疼痛位置与诱发条件。')
s=new('四、疼痛程度：四种方法依次学习','第二节  疼痛评定方法','第17页','教材的顺序是VAS、NRS、VRS、FPS。四种方法都是了解体验强度的工具，选择时考虑理解和表达能力。复测尽量保持同一工具、同一条件。')
steps(s,[('① 视觉模拟','VAS\n在线段上标记'),('② 数字评分','NRS\n选择0—10的数字'),('③ 口述分级','VRS\n选择描述词'),('④ 面部表情','FPS\n选择相应面孔')])
text(s,.9,5.8,11.6,.6,'先固定条件：现在，还是过去一周？静息，还是完成某个活动时？',21,RED,True)
s=new('（一）视觉模拟评分法：VAS','第二节  疼痛评定方法','第17页','纸上画10厘米线段，两端分别表示无痛和极痛，患者自行标记。测量从无痛端到标记点的距离。教材建议评估两次并取平均值。此处屏幕图是教学示意，不能直接当成10厘米临床测量工具。')
line(s,1.1,3.2,7.3,3.2,DARK,3);line(s,1.1,3.0,1.1,3.4,DARK);line(s,7.3,3.0,7.3,3.4,DARK)
text(s,.9,3.55,2,.5,'无痛（0）',21);text(s,6.1,3.55,2,.5,'极痛（100）',21)
line(s,4.6,2.95,4.6,3.45,RED,3);text(s,3.45,2.3,3,.5,'患者自行标记',21,RED,True)
text(s,1.1,4.45,6.5,1.25,'纸上实际长度为10厘米\n例如：测得35毫米，记录为35/100。',23)
card(s,8.1,2.2,4.5,3.9,'操作要点','理解两端含义\n独立选择标记位置\n记录距离与评估条件\n本页线段仅为教学示意')
s=new('（二）数字评分法：NRS','第二节  疼痛评定方法','第17页','让患者从0到10选择最能代表疼痛程度的数字。0无痛，10最剧烈的疼痛。示例评分不能转换成损伤程度。数字工具便于随访，但不能替代完整问诊。')
for i in range(11):
 shape(s,.85+i*1.07,2.65,.88,.88,LIGHT if i!=4 else RED,kind=MSO_SHAPE.ROUNDED_RECTANGLE)
 text(s,.85+i*1.07,2.8,.88,.5,str(i),26,RED if i!=4 else 'FFFFFF',True,PP_ALIGN.CENTER)
text(s,.85,3.75,4,.5,'0：无痛',23);text(s,8.4,3.75,4,.5,'10：最剧烈的疼痛',23)
card(s,.85,4.6,11.65,1.45,'同一分值，需要具体情境','“今天步行10分钟时为4/10；静息时为1/10。”')
s=new('（三）口述分级评分法：VRS','第二节  疼痛评定方法','第17页','依教材使用按疼痛强弱排列的描述词。患者选择最符合当前体验的一项。不要擅自把这些词映射成固定的NRS数字区间。')
labels=['无痛','轻度疼痛','中度疼痛','重度疼痛','剧烈疼痛','无法忍受']
for i,a in enumerate(labels):
 x=.8+(i%3)*4.16;y=2.3+(i//3)*1.7
 shape(s,x,y,3.9,1.1,'FFF2EC');text(s,x+.1,y+.3,3.7,.5,a,25,RED,True,PP_ALIGN.CENTER)
text(s,.95,6.1,11.6,.5,'使用同一套词语和相同提问条件，便于前后比较。',22,GREY)
s=new('（四）面部表情评分法：FPS','第二节  疼痛评定方法','第17页','教材介绍六种表情组成的评定方法，常用于儿童等群体。正式使用时必须采用具体量表的标准图卡与指导语，不能把随意绘制的笑脸哭脸当作标准量表，也不应只观察患者表情代替其选择。')
steps(s,[('选合适工具','考虑年龄、理解与沟通能力\n选用正式图卡及其指导语'),('由本人选择','说明每张面孔代表的疼痛变化\n让受评者选择自己的感受'),('按版本记录','记录量表名称与版本\n遵循该版本的计分方法')])
text(s,.9,5.8,11.6,.65,'核心：评的是疼痛程度；面孔不是“开心或伤心”的测试。',22,RED,True)
s=new('四种评分方法如何选择？','第二节  疼痛评定方法','第17页 · 教学归纳','这是对前面四种方法的归纳，不改变教材章节顺序。能理解数字者可用NRS，能理解连续线段者可用VAS，偏好语言描述者可选VRS，合适的儿童群体可用经验证FPS版本。')
rows=[('VAS','连续线段标记','理解端点并完成线段定位'),('NRS','0—10数字选择','理解数字及其强弱含义'),('VRS','描述词语选择','理解分级词汇'),('FPS','标准面孔选择','使用适龄版本和标准指导语')]
for i,(a,b,c) in enumerate(rows):
 y=2.15+i*.9;shape(s,.8,y,11.7,.78,'F6F7F9' if i%2==0 else LIGHT);text(s,1,y+.15,1.2,.5,a,22,RED,True);text(s,2.55,y+.15,3.4,.5,b,22);text(s,6.25,y+.15,5.9,.5,c,21)
text(s,1,6.15,11.4,.4,'连续随访：优先保持工具、活动任务和评估时点一致。',20,RED,True)
s=new('五、疼痛的发展进程：把症状放进时间轴','第二节  疼痛评定方法','第18页','依教材询问持续或间断、活动前中后、晨起夜间及一天结束时的变化，确认是否伴功能障碍以及治疗前后的变化。时间模式提供线索，不单独确诊炎症或某种损伤。')
steps(s,[('何时出现','持续还是间断？\n急性还是慢性？'),('何时变化','活动前、活动中、活动后？\n晨起、夜间、一天结束？'),('伴随与处理','有无功能受限？\n接受过何种处理？\n处理后发生什么变化？')])
text(s,.9,5.8,11.6,.6,'记录活动时段与恢复过程，比只问“今天痛几分”提供更多信息。',21,RED,True)
s=new('六、疼痛加重和缓解的因素','第二节  疼痛评定方法','第18页','依教材了解体位、姿势和动作的影响。对于激惹性较高者，评估中避免反复诱发明显症状。除身体因素外，也需了解情绪、注意、经历和康复需求。')
card(s,.7,2.15,5.8,3.95,'活动与姿势','哪些动作会加重？\n哪些姿势或活动会缓解？\n停止活动后多久恢复？\n是否影响正常行走、上下楼或睡眠？')
card(s,6.8,2.15,5.8,3.95,'个体与环境','年龄、情绪与注意力\n既往疼痛经历与个人特点\n社会文化背景与当前需求\n结合多方面信息制定康复方案')
s=new('七、疼痛的结果记录：SAND 原则','第二节  疼痛评定方法','第18—19页','严格按教材SAND含义：S严重程度；A疼痛部位；N疼痛性质，教材同时包括持续或间断；D深度，即深部或表浅。D不是duration，不要把深度写成持续时间。')
for i,(a,b,c) in enumerate([('S','严重程度','量表名称、分值与评估条件'),('A','部位','在身体图上标出位置和范围'),('N','性质','钝痛、刺痛、灼痛等；持续或间断'),('D','深度','表浅或深部；描述定位清晰程度')]):
 y=2.15+i*.96;shape(s,.8,y,.8,.76,RED,kind=MSO_SHAPE.ROUNDED_RECTANGLE);text(s,.8,y+.12,.8,.5,a,28,'FFFFFF',True,PP_ALIGN.CENTER);text(s,1.9,y+.14,2.2,.45,b,23,RED,True);text(s,4.4,y+.14,8.1,.5,c,22)
s=new('记录示例：从一句“膝痛”到可复测的信息','第二节  疼痛评定方法','第18—19页 · 教学案例','情境为虚构的教学案例。学生参加一次跑跳活动后膝部不适，也可换成足球训练。强调描述与诊断分开，不能用这一记录直接确认损伤。')
card(s,.7,2.1,5.8,4.35,'SAND 核心记录','S：今日下楼时 NRS 4/10，静息1/10\nA：右膝前侧，已在身体图标记\nN：酸痛，间断出现\nD：自述深部，定位不十分清晰')
card(s,6.8,2.1,5.8,4.35,'补充评定背景','两周前开始，无明确单次外伤\n下楼、重复蹲起时加重\n休息后减轻，影响日常上下楼\n后续需结合体格检查与功能评定')
s=new('课堂练习：你还需要追问什么？','课堂应用','第19页思考题 · 教学案例','给学生一分钟列追问，再按病史、部位、性质、程度、进程、影响因素、结果记录核对。答案在讲解备注中，不要在投影上立即展示。参考：何时开始；位置范围深度；性质；具体时段和活动；量表与条件；加重缓解；既往史与处理；功能影响。')
card(s,.8,2.2,11.7,1.7,'来访者的描述','“我最近运动后脚踝不舒服，休息会好一些，但不知道算不算严重。”')
text(s,1.05,4.35,11.2,1.8,'① 按教材七项顺序提出追问。\n② 选择一种评分工具，说明评估条件。\n③ 还缺少哪些信息，才能形成 SAND 记录？',25)
s=new('回到教材的三道思考题','复习与讨论','第19页','参考答案：VAS需解释两端含义、10厘米线标记、测距并记录条件；评定内容为第二节七项；SAND依次严重程度、部位、性质、深度。提醒学生疼痛分数只是评定的一部分。')
text(s,1.05,2.3,11.3,3.6,'1. 如何使用 VAS 方法评定疼痛？\n2. 疼痛评定包括哪些内容？\n3. SAND 分别记录什么？',29)
text(s,1.05,5.65,11.3,.8,'疼痛评定的目标：理解个体体验，识别功能影响，形成可比较的记录。',23,RED,True)
s=new('教材与补充资料','参考资料','第15—19页及章首页','主要内容来自用户提供的第二章教材扫描件，顺序与教材一致。IASP定义和VAS资料仅作更新与操作补充。模板来自用户提供肌骨概述PPTX，图片和文字结构并未作为疼痛知识来源。')
text(s,.9,2.1,11.7,3.9,'主要依据\n《运动康复评定学》第二章“疼痛的运动康复评定”，用户提供扫描件，章首页及第15—19页。\n\n补充资料\n国际疼痛学会（IASP）：2020年修订疼痛定义及相关说明。\nNSW Agency for Clinical Innovation：视觉模拟评分法操作资料。\n\n模板：《肌骨概述.pptx》（用户提供）。',20)
p.save(str(ROOT/'Chapter2_Pain_Assessment.pptx'))
(ROOT/'顺序核对.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
(ROOT/'逐页讲解备注.md').write_text('# 第二章 疼痛的运动康复评定｜逐页讲解备注\n\n'+ '\n\n'.join(f'## {r["slide"]:02} {r["title"]}\n\n教材位置：{r["source"]}\n\n{r["note"]}' for r in records)+'\n\n参考链接：\n- https://www.iasp-pain.org/publications/iasp-news/iasp-announces-revised-definition-of-pain/\n- https://aci.health.nsw.gov.au/__data/assets/pdf_file/0018/212913/ACI-Pain-assessment-tools-visual-analogue-scale.pdf\n')
print('Built',len(p.slides),'slides')
