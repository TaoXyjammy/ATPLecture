from pathlib import Path
import json
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent;AS=Path(__file__).parent/'assets'
p=Presentation(str(Path(__file__).parent/'肌骨概述.pptx'))
for sid in list(p.slides._sldIdLst):p.part.drop_rel(sid.rId);p.slides._sldIdLst.remove(sid)
RED='C72F3A';ACC='FF4726';DEEP='A71D25';BLUE='287DB2';GOLD='B78117';PURPLE='8051A6';DARK='263442';GREY='697580';WHITE='FFFFFF';PALE='F5F7FA'
records=[]
def box(s,x,y,w,h,c):
 z=s.shapes.add_shape(1,Inches(x),Inches(y),Inches(w),Inches(h));z.fill.solid();z.fill.fore_color.rgb=RGBColor.from_string(c);z.line.fill.background();return z
def tx(s,x,y,w,h,t,size=22,c=DARK,bold=False,align=None):
 z=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));f=z.text_frame;f.word_wrap=True;f.margin_left=f.margin_right=Inches(.025);f.margin_top=Inches(.02);f.margin_bottom=0
 for i,a in enumerate(t.split('\n')):
  q=f.paragraphs[0] if i==0 else f.add_paragraph();q.text=a;q.font.name='Noto Sans CJK SC';q.font.size=Pt(size);q.font.bold=bold;q.font.color.rgb=RGBColor.from_string(c);q.space_after=Pt(10)
  if align is not None:q.alignment=align
 return z
def picture(s,name,x,y,w,h,region=(0,0,1,1),contain=True):
 im=Image.open(AS/name);iw,ih=im.size;l,t,r,b=region;ar=iw*(r-l)/(ih*(b-t))
 if contain:
  if ar>w/h:hh=w/ar;yy=y+(h-hh)/2;xx=x;ww=w
  else:ww=h*ar;xx=x+(w-ww)/2;hh=h;yy=y
 else:xx=x;yy=y;ww=w;hh=h
 z=s.shapes.add_picture(str(AS/name),Inches(xx),Inches(yy),Inches(ww),Inches(hh));z.crop_left=l;z.crop_top=t;z.crop_right=1-r;z.crop_bottom=1-b
 return (xx,yy,ww,hh)
def label(s,x,y,w,t,c=DARK):
 box(s,x,y,w,.36,WHITE);tx(s,x,y,w,.35,t,16,c,True)
def base(title,sect,page,note):
 s=p.slides.add_slide(p.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor.from_string(WHITE)
 box(s,0,0,13.333,.2,ACC);tx(s,.6,.4,11.8,.35,'第二章  运动与骨骼肌',15,DEEP,True)
 tx(s,.6,1.02,12.1,.65,title,29,DARK,True);box(s,.62,1.85,.8,.05,RED)
 tx(s,.6,6.83,11.6,.23,sect+'  ·  '+page,10,GREY);tx(s,12.15,6.78,.55,.3,f'{len(records)+1:02}',12,DEEP,True)
 box(s,0,7.14,13.333,.06,ACC)
 s.notes_slide.notes_text_frame.text=note+'\n\n教材依据：《运动生理学》（第6版），第二章第一节，'+page+'。结构图为参考教材的彩色教学重绘；曲线与尺寸不作为实测数据。'
 tr=OxmlElement('p:transition');tr.set('spd','med');tr.append(OxmlElement('p:fade'));s._element.append(tr)
 records.append({'slide':len(records)+1,'title':title,'section':sect,'page':page,'note':note});return s
def right(s,title,body,y=2.3):
 tx(s,8.45,y,4.2,.6,title,24,DEEP,True);tx(s,8.45,y+.8,4.2,3.5,body,22)
def card(s,x,y,w,h,a,b,c=DEEP):
 box(s,x,y,w,h,PALE);box(s,x,y,.045,h,c);tx(s,x+.17,y+.16,w-.3,.5,a,23,c,True);tx(s,x+.17,y+.9,w-.3,h-1.0,b,21)
# cover
s=p.slides.add_slide(p.slide_layouts[6]);box(s,0,0,5.5,7.5,DEEP);picture(s,'fig2_1_ultrastructure.png',5.65,.55,7.4,6.4)
tx(s,.6,.75,4.4,.55,'运动生理学',23,WHITE,True);tx(s,.6,1.8,4.35,2.0,'骨骼肌的结构\n与生物电现象',33,WHITE,True)
tx(s,.65,4.15,4.25,1.5,'第一节  第一、第二部分\n超微结构与肌丝滑行学说\n骨骼肌细胞的生物电现象',20,WHITE);tx(s,.65,6.4,4.1,.5,'主讲：谢淘',22,WHITE)
s.notes_slide.notes_text_frame.text='本课依教材顺序讲解第一节中的第一、第二部分：先认识骨骼肌超微结构及肌丝滑行学说，再理解骨骼肌细胞的生物电现象。范围为第12—18页，止于动作电位的传导，不进入神经—肌肉接头及兴奋—收缩耦联。'
records.append({'slide':1,'title':'骨骼肌的结构与生物电现象','section':'封面','page':'第12—18页','note':s.notes_slide.notes_text_frame.text})
# preliminary structure follows book introductory paragraphs
s=base('从肌肉到肌纤维：先明确结构层级','第一节  结构基础','第12页','肌细胞又称肌纤维，是肌肉的基本结构和功能单位。先按肌肉、肌束、肌纤维的层级说明，再进入肌原纤维与肌小节。肌内膜、肌束膜和肌外膜分别包绕相应层级，不要把肌内膜与肌膜混为同一结构。')
picture(s,'fig2_1_ultrastructure.png',.6,2.2,7.35,4.35,(0,0,1,.61))
right(s,'肌纤维＝肌细胞','肌肉：外有肌外膜\n肌束：外有肌束膜\n肌纤维：外有肌内膜\n肌纤维内含多条肌原纤维\n成人肌纤维直径约60 μm')
# figure2-1 overview
s=base('（一）肌原纤维与肌小节','一、超微结构及肌丝滑行学说','第12—13页 · 图2-1','每条肌纤维内含多条平行排列的肌原纤维，肌原纤维由粗、细肌丝规律排列构成。沿长轴交替出现A带与I带，是横纹的结构基础。按图中层级逐项指认，避免把肌原纤维与肌纤维当成同义词。')
xx,yy,ww,hh=picture(s,'fig2_1_ultrastructure.png',.58,2.1,7.55,4.5)
for fx,fy,t in [(.66,.05,'肌肉'),(.70,.28,'肌束'),(.79,.48,'肌纤维'),(.02,.68,'肌原纤维'),(.02,.83,'粗肌丝'),(.02,.94,'细肌丝')]:label(s,xx+ww*fx,yy+hh*fy,1.35,t,BLUE if t=='细肌丝' else DARK)
right(s,'有序排列形成横纹','肌原纤维沿肌纤维长轴排列。\nA带：暗带\nI带：明带\n粗、细肌丝按规律排列。\n肌原纤维直径约1～2 μm。')
# precise sarcomere
s=base('一个肌小节：相邻两条Z线之间','一、（一）肌原纤维与肌小节','第13页 · 图2-1补充放大','相邻两条Z线之间为肌小节，是肌原纤维最基本的结构和功能单位。细肌丝连接Z线并伸向中央，粗肌丝位于中央。A带对应粗肌丝全长；H区在A带中央，只含粗肌丝；I带只含细肌丝。以图说明位置而不是只背缩写。')
picture(s,'sarcomere_bands.png',.6,2.35,7.5,3.8)
right(s,'先定位，再区分条带','Z线：肌小节边界\nA带：粗肌丝全长\nH区：A带中央、仅有粗肌丝\nI带：仅有细肌丝\n静息肌小节约2.0～2.2 μm')
s=base('粗、细肌丝的空间排列','一、（一）肌原纤维与肌小节','第13页','教材指出，在粗细肌丝重叠区，每一根粗肌丝被6根细肌丝包绕。规则的空间关系为横桥接触细肌丝创造条件。图为横断面局部示意，不代表全部肌原纤维横断面。')
picture(s,'filament_lattice.png',1,2.15,5.8,4.35);card(s,7.25,2.5,5.1,3.55,'重叠区的排列','每根粗肌丝周围有6根细肌丝。\n规则排列有利于粗、细肌丝相互作用。\n此图为横断面局部放大。')
# figure2-2
s=base('（二）肌管系统：横管与纵管','一、超微结构及肌丝滑行学说','第13—14页 · 图2-2','横管即T管，是肌膜向肌纤维内部凹陷形成的结构。纵管即肌质网，沿肌原纤维周围分布，走向以纵向为主。注意T管腔与细胞外相连，肌质网则是另一个膜性系统，二者不能画成相通的管道。本次只讲结构，不展开后面的兴奋—收缩耦联。')
xx,yy,ww,hh=picture(s,'fig2_2_tubules.png',.6,2.12,7.55,4.5)
label(s,xx+.1,yy+.10,2,'肌膜',DARK);label(s,xx+ww*.43,yy+.6,2,'肌质网（纵管）',BLUE);label(s,xx+.2,yy+hh*.52,2.3,'横管（T管）',GOLD)
right(s,'两套不同的膜性结构','横管：肌膜向内凹陷形成。\n纵管：肌质网，包绕肌原纤维。\n两者相邻，但内腔不相通。')
s=base('三联管：一条横管与两侧终末池','一、（二）肌管系统','第13—14页 · 图2-2局部','肌质网在接近横管处扩大形成终末池。每条横管与两侧终末池构成三联管。教材指出两种膜性结构并不直接接触，约有12nm间隙，管腔不相通。图像是结构关系放大，不按比例表示间隙。')
xx,yy,ww,hh=picture(s,'fig2_2_tubules.png',.7,2.35,7.1,3.9,(.615,.51,1,.89))
label(s,xx+.2,yy+.15,2.6,'终末池',BLUE);label(s,xx+.2,yy+hh*.43,2.6,'横管',GOLD);label(s,xx+.2,yy+hh*.77,2.6,'终末池',BLUE)
right(s,'“三”指三个相邻部分','一条横管\n两侧各有一个终末池\n相邻膜之间有间隙\n不代表三个内腔相互连通')
# composition
s=base('（三）肌丝的分子组成：粗肌丝','一、超微结构及肌丝滑行学说','第14页','粗肌丝主要由肌球蛋白组成。肌球蛋白分子有杆状尾部和头部，许多分子聚集形成粗肌丝，突出的头部构成横桥。横桥具有ATP酶活性，可与细肌丝的肌动蛋白结合并产生作用。本页只说明组成和功能，不讲本次范围之外的完整横桥循环。')
picture(s,'fig2_1_ultrastructure.png',.7,2.7,7.35,2.7,(.35,.765,.89,.915))
label(s,1.2,2.3,2.5,'肌球蛋白头部（横桥）',RED)
right(s,'肌球蛋白是主要成分','杆状尾部：参与形成粗肌丝主干。\n头部：向外突出，构成横桥。\n横桥具有ATP酶活性，参与粗、细肌丝相互作用。')
s=base('细肌丝：肌动蛋白、原肌球蛋白与肌钙蛋白','一、（三）肌丝的分子组成','第14页 · 图2-3','细肌丝由肌动蛋白、原肌球蛋白和肌钙蛋白组成。肌动蛋白为双螺旋骨架；原肌球蛋白沿沟槽分布；肌钙蛋白由C、T、I三个成分构成。彩色图表达组成关系，分子形状和大小是教学示意，不视为精确原子模型。')
xx,yy,ww,hh=picture(s,'fig2_3_thin_filament.png',.65,2.1,12.0,2.95)
# Native Chinese labels align with the color-coded redraw.
label(s,1.0,4.85,2.8,'肌动蛋白（蓝）',BLUE);label(s,4.0,4.85,3.4,'原肌球蛋白（金）',GOLD);label(s,8.0,4.85,4.0,'肌钙蛋白复合体',DARK)
tx(s,1,5.62,11.5,.9,'肌钙蛋白C：绿色    肌钙蛋白T：紫色    肌钙蛋白I：红色',22,DARK)
# fig2-4
s=base('（四）肌丝滑行学说','一、超微结构及肌丝滑行学说','第14—15页 · 图2-4','Huxley等观察到，收缩时A带长度不变，而I带和H区缩短；被拉长时则相反。这说明并非粗细肌丝自身变短，而是细肌丝在横桥作用下向A带中央滑动，使Z线相互靠近，肌小节缩短。本图三种状态按教材顺序排列。')
picture(s,'fig2_4_sliding.png',.6,2.12,7.55,4.5)
right(s,'肌丝长度不变，重叠改变','细肌丝向肌小节中央滑行。\nZ线相互靠近，肌小节缩短。\n多个肌小节的变化共同形成肌原纤维长度变化。')
s=base('收缩时，哪些变短，哪些不变？','一、（四）肌丝滑行学说','第14—15页','用条带变化反推滑行机制。肌小节、I带、H区可缩短；A带、粗肌丝长度和细肌丝长度不因滑行而缩短。H区可在充分缩短时消失，但不是所有收缩都必然完全消失。此处讲的是教材中的滑行结构变化。')
card(s,.75,2.4,5.75,3.8,'发生变化','Z线间距缩小\nI带变窄\nH区变窄，可消失',BLUE)
card(s,6.85,2.4,5.75,3.8,'长度保持不变','A带\n粗肌丝\n细肌丝',RED)
# second part
s=base('二、骨骼肌细胞的生物电现象','第一节  生物电现象','第15页','按教材进入第二部分。一切活细胞都有电活动，称为生物电。可兴奋细胞受到刺激发生兴奋时，可以出现动作电位。动作电位是兴奋的标志之一，产生动作电位的能力称为兴奋性。心电图、脑电图、肌电图记录的是相应组织细胞电活动的综合变化。')
card(s,.75,2.3,5.75,3.9,'从电活动理解兴奋','生物电：活细胞的电活动。\n动作电位：可兴奋细胞兴奋时出现的可传播电位变化。\n兴奋性：产生动作电位的能力。')
card(s,6.85,2.3,5.75,3.9,'记录电活动的例子','心电图：心脏电活动\n脑电图：脑部电活动\n肌电图：骨骼肌电活动',BLUE)
s=base('（一）静息电位：静息时的跨膜电位差','二、骨骼肌细胞的生物电现象','第15—16页','静息电位指细胞处于静息状态时膜内外的电位差。以膜外为零，神经和肌肉等细胞常在约−70至−90mV范围，依细胞类型而异。静息时呈膜内负、膜外正的极化状态。负号指膜内相对膜外，不能把它解释为整个细胞内部有大量净负电荷。')
box(s,1.0,2.6,4.9,2.2,PALE);tx(s,1.35,3.0,4.2,1.0,'约 −70～−90 mV',34,BLUE,True,PP_ALIGN.CENTER)
tx(s,1.2,5.2,4.8,.6,'膜外电位作为零电位参照',21,GREY,False,PP_ALIGN.CENTER)
right(s,'“负”是相对膜外而言','静息时：膜内相对负，膜外相对正。\n这种状态称为极化。\n具体数值随细胞与条件而异。')
s=base('静息电位怎样形成？','二、（一）静息电位','第15—16页 · 图2-5','细胞内K浓度较高，静息时膜对K的通透性较高，K沿浓度梯度外流。少量电荷分离使膜内相对变负，形成阻碍继续外流的电场。当电驱动力与扩散驱动力相抵时，K趋于电化学平衡。教材以K平衡解释静息电位的基础，实际膜电位还与其他离子的通透性有关。灰箭头表示电驱动力，不是另一条K主动运输通路。')
picture(s,'fig2_5_resting_potential.png',.65,2.1,7.4,4.5,(0,0,.64,1))
right(s,'浓度梯度与电位差共同作用','K⁺浓度梯度推动外流。\n膜内相对变负，电位差阻碍继续外流。\n两种驱动力趋于平衡。')
s=base('选择性通透与钠—钾泵的作用','二、（一）静息电位','第15—16页 · 图2-5局部','静息电位的基础是离子浓度差和膜的选择性通透。钠钾泵消耗ATP，维持跨膜Na与K梯度。它不是每次动作电位下降支的直接成因；快速复极化主要是通道通透性变化，尤其K外流。泵的3Na外运2K内运为辅助解释，不改变教材以离子学说讲解的顺序。')
picture(s,'fig2_5_resting_potential.png',.8,2.1,6.6,4.5,(.64,0,1,1))
right(s,'钠—钾泵维持离子梯度','静息膜对不同离子的通透性不同。\n钠—钾泵消耗ATP。\n每轮外运3个Na⁺，内运2个K⁺。\n持续维持离子浓度差。')
s=base('（二）动作电位：在静息电位基础上的变化','二、骨骼肌细胞的生物电现象','第16页 · 图2-6','可兴奋细胞兴奋时产生的可传播电位变化称为动作电位。动作电位是连续变化过程，产生后可沿细胞膜传播。本图以教材示例的静息约−90mV和峰值约+30mV说明形态，数值和时程不作为所有细胞的统一标准。')
picture(s,'fig2_6_action_potential.png',.55,2.15,7.8,4.4);right(s,'两个特征','教材以神经细胞为例说明。\n在静息电位基础上产生。\n一旦在膜的一处发生，能够沿膜传播。\n主要变化表现为快速上升与快速下降。')
s=base('1．动作电位的变化过程','二、（二）动作电位','第16—17页 · 图2-6','教材把动作电位分为峰电位和后电位，也可按去极化与复极化理解。上升过程中膜内负电位减小，称去极化；超过零电位后膜内变正，称反极化。下降过程中回到原先极化状态，称复极化。后电位包括较缓慢的后续变化。')
picture(s,'fig2_6_action_potential.png',.55,2.15,7.8,4.4)
right(s,'顺着曲线描述变化','上升支：去极化、反极化\n下降支：复极化\n峰电位之后：后电位\n随后恢复静息状态')
s=base('2．动作电位的产生原理','二、（二）动作电位','第17页','刺激达到阈值后，电压门控Na通道大量开放，Na沿电化学驱动力内流，形成上升支。随后Na通道失活，K通道开放增加，K外流主导复极化。避免说成Na通道一直关闭或把Na失活等同于静息关闭。离子泵长期维持梯度，而非直接造成一次动作电位的快速下降。')
card(s,.75,2.35,5.75,3.9,'上升支：Na⁺内流','达到阈值\nNa⁺通道开放增加\nNa⁺快速内流\n膜内电位上升',RED)
card(s,6.85,2.35,5.75,3.9,'下降支：K⁺外流','Na⁺通道失活\nK⁺通道开放增加\nK⁺外流\n膜电位向静息水平恢复',BLUE)
s=base('（三）动作电位与兴奋性变化','二、骨骼肌细胞的生物电现象','第17页 · 图2-7','按教材依次讲绝对不应期、相对不应期、超常期和低常期。绝对不应期不能再次产生动作电位；相对不应期需较强刺激；超常期兴奋性高于正常；低常期低于正常。上下曲线在同一时间轴对照。图形为定性示意，各期的时长因细胞与条件不同而异，不把色块宽度当作实测值。')
picture(s,'fig2_7_excitability.png',.55,2.05,7.8,4.6)
right(s,'四个阶段依次出现','绝对不应期：不能再次兴奋\n相对不应期：需较强刺激\n超常期：兴奋性高于正常\n低常期：兴奋性低于正常')
s=base('动作电位的三个特点','二、（三）兴奋性变化过程','第17—18页','教材在兴奋性变化之后列出动作电位的三个特点。全或无是指单个可兴奋细胞的动作电位达到阈值后产生完整反应，幅度不随刺激增强而增大；不衰减是主动再生传播的特点；脉冲式存在与不应期有关。整体肌肉力量仍可通过募集、放电频率等改变，但这些不属于动作电位幅度增强。')
for i,(a,b) in enumerate([('全或无','达到阈值后产生完整动作电位；幅度不随刺激继续增强而增大。'),('不衰减传导','相邻膜区依次产生动作电位，幅度不随传导距离而递减。'),('脉冲式存在','不应期限制连续反应，动作电位之间存在一定间隔。')]):
 y=2.18+i*1.4;box(s,.75,y,11.85,1.15,PALE);tx(s,.95,y+.2,2.7,.55,a,24,DEEP,True);tx(s,3.85,y+.18,8.35,.83,b,22)
s=base('（四）动作电位的传导','二、骨骼肌细胞的生物电现象','第18页','细胞膜某处产生动作电位后，可沿膜传播，依次引起相邻膜区兴奋。教材以局部电流解释无髓神经纤维传导。在完整纤维中段人工刺激时可向两侧传导，不能把这一实验现象理解为正常神经信号在所有生理情境下随意双向传递。肌纤维膜的传播使兴奋扩展到细胞膜。本次到此结束，不进入第三部分神经肌肉接头。')
picture(s,'propagation.png',.65,2.4,7.45,3.65)
right(s,'相邻膜区依次兴奋','兴奋区与邻近区域形成局部电流。\n邻近膜达到阈值，产生动作电位。\n波形随传播被不断再生。\n中段人工刺激完整纤维，可向两侧传导。')
s=base('本课回顾：结构、滑行与电活动','第一节  第一、第二部分','第12—18页','按教材顺序回顾两部分，不跨入接头与耦联。结构层面认识肌小节，机械层面区分肌丝长度与重叠程度，电活动层面理解静息电位、动作电位、兴奋性和传播。')
card(s,.75,2.35,5.75,3.9,'一、结构与肌丝滑行','肌原纤维与肌小节\n横管、纵管与三联管\n粗、细肌丝的分子组成\n肌丝滑行导致肌小节缩短')
card(s,6.85,2.35,5.75,3.9,'二、生物电现象','静息电位：跨膜电位差\n动作电位：快速电位变化\n兴奋性随过程改变\n动作电位沿膜传播',BLUE)
s=base('课堂练习','复习与讨论','第12—18页','参考答案：1相邻Z线之间；2A带、粗细肌丝长度不变，I带H区变窄，Z线靠近；3一条横管与两侧终末池，内腔不相通；4Na内流为主、K外流为主；5绝对不应期与相对不应期的刺激反应不同。可根据授课时间选择口头提问或课后书面练习。')
tx(s,.9,2.25,11.7,4.2,'1．如何界定一个肌小节？\n2．收缩时，A带、I带、H区分别怎样变化？\n3．三联管由哪三部分组成？内腔是否相通？\n4．动作电位上升支与下降支分别以哪种离子移动为主？\n5．绝对不应期与相对不应期有何区别？',25)
s=base('教材与图示说明','参考资料','第12—18页','唯一课程内容依据为用户上传《运动生理学》（第6版）第二章第一节第一、第二部分。图2-1至图2-3为参照教材的AI彩色结构重绘，中文标注在PPT中叠加；图2-4至图2-7为依据教材关系精确绘制的彩色教学图。曲线为定性示意，无真实实验数据。源文件含可复用图像和绘图代码，不上传教材扫描全文。')
tx(s,.85,2.2,11.7,3.8,'教材\n《运动生理学》（第6版），第二章“运动与骨骼肌”\n第一节“骨骼肌的结构特点与收缩原理”，第12—18页。\n\n彩色图示\n图2-1—图2-3：参照教材的结构重绘，中文标注为可编辑文字。\n图2-4—图2-7：依据教材关系绘制；尺寸、时程与曲线为教学示意。',22)
p.save(ROOT/'Skeletal_Muscle_Structure_Bioelectricity.pptx')
(ROOT/'教材顺序核对.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
(ROOT/'逐页讲解备注.md').write_text('# 骨骼肌的结构与生物电现象\n\n'+ '\n\n'.join(f'## {r["slide"]:02} {r["title"]}\n\n教材：{r["page"]}\n\n{r["note"]}' for r in records))
print('Built',len(p.slides),'slides')
