from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Circle,Rectangle,FancyBboxPatch,Ellipse
from matplotlib.path import Path as MPath
from matplotlib.patches import PathPatch
AS=Path(__file__).parent/'assets';AS.mkdir(exist_ok=True)
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams.update({'font.family':['Noto Sans CJK JP','DejaVu Sans'],'font.size':14,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white','axes.unicode_minus':False})
RED='#C72F3A';BLUE='#287DB2';PURPLE='#8051A6';GOLD='#E5AB34';DARK='#263442';GREY='#73808C'
def save(fig,name):
 fig.savefig(AS/(name+'.png'),dpi=220,bbox_inches='tight',pad_inches=.12);fig.savefig(AS/(name+'.svg'),bbox_inches='tight',pad_inches=.12);plt.close(fig)
def bracket(ax,x1,x2,y,label,color=DARK):
 ax.plot([x1,x1,x2,x2],[y+.06,y,y,y+.06],color=color,lw=1.5);ax.text((x1+x2)/2,y-.06,label,ha='center',va='top',fontsize=13,color=color)
def sarcomere(ax,half,y,title,bands=False):
 ax.add_patch(Rectangle((-2.7,y-.38),5.4,.76,color=RED,alpha=.09))
 for dy in [-.25,0,.25]:
  ax.plot([-2.7,2.7],[y+dy,y+dy],color=RED,lw=6,solid_capstyle='round')
  ax.plot([-half,-half+4],[y+dy+.10,y+dy+.10],color=BLUE,lw=2.6)
  ax.plot([half-4,half],[y+dy+.10,y+dy+.10],color=BLUE,lw=2.6)
 for z in [-half,half]:ax.plot([z,z],[y-.48,y+.48],color=PURPLE,lw=4)
 ax.text(-7,y,title,ha='left',va='center',fontsize=17,color=DARK)
 if bands:
  ax.text(-half,y+.65,'Z线',ha='center',color=PURPLE);ax.text(half,y+.65,'Z线',ha='center',color=PURPLE)
  bracket(ax,-2.7,2.7,y-.65,'A带（粗肌丝全长）',RED)
  bracket(ax,-half,-2.7,y-.65,'半个I带',BLUE)
  bracket(ax,2.7,half,y-.65,'半个I带',BLUE)
  if half>4:bracket(ax,-(half-4),half-4,y+.75,'H区',GREY)
# fig 2-4, preserve original top/shortened/stretched sequence.
f,ax=plt.subplots(figsize=(12.5,6.2));ax.set(xlim=(-7.2,6.5),ylim=(-.6,6));ax.axis('off')
sarcomere(ax,5,4.75,'静息状态',True);sarcomere(ax,4,2.75,'缩短状态');sarcomere(ax,6,.75,'被拉长状态')
ax.text(-.2,-.25,'粗肌丝、细肌丝长度不变；改变的是重叠程度与Z线间距。',ha='center',color=DARK,fontsize=15)
save(f,'fig2_4_sliding')
# A separate precise enlargement supporting fig2-1 sarcomere bands.
f,ax=plt.subplots(figsize=(11,4));ax.axis('off');ax.set(xlim=(-6.3,6.3),ylim=(-1.5,2.3));sarcomere(ax,5,.35,'',True)
ax.text(-3.85,1.9,'细肌丝',color=BLUE,ha='center');ax.text(0,1.9,'粗肌丝',color=RED,ha='center');ax.text(0,-1.3,'一个肌小节：相邻两条Z线之间',ha='center',fontsize=17,color=DARK)
save(f,'sarcomere_bands')
# Cross sectional lattice: one thick filament surrounded by six thin filaments.
f,ax=plt.subplots(figsize=(5.6,5));ax.set_aspect('equal');ax.axis('off');ax.set(xlim=(-2,2),ylim=(-1.7,1.8))
ax.add_patch(Circle((0,0),.28,color=RED));
for a in np.arange(6)*np.pi/3:
 x,y=np.cos(a),np.sin(a);ax.add_patch(Circle((x,y),.15,color=BLUE));ax.plot([x*.35,x*.78],[y*.35,y*.78],color='#BDC9D2',ls=':',lw=1)
ax.text(0,1.55,'粗、细肌丝在重叠区的排列',ha='center',fontsize=17,color=DARK)
ax.text(0,-1.4,'红：粗肌丝    蓝：细肌丝',ha='center',fontsize=15,color=DARK);save(f,'filament_lattice')
# fig2-5: ionic gradients, selective permeability and pump.
f,ax=plt.subplots(figsize=(12,6.8));ax.axis('off');ax.set(xlim=(0,12),ylim=(0,6.8))
for yy in [2.72,3.28]:
 for xx in np.arange(.3,11.9,.3):
  ax.add_patch(Circle((xx,yy),.085,color='#E6B16F',ec='#AD7843',lw=.4))
  sign=1 if yy<3 else -1
  ax.plot([xx-.025,xx-.025],[yy+.08*sign,3.0],color='#CBA06C',lw=.9)
  ax.plot([xx+.025,xx+.025],[yy+.08*sign,3.0],color='#CBA06C',lw=.9)
ax.text(.2,6.4,'细胞外：Na⁺相对多，K⁺相对少',fontsize=18,color=DARK)
ax.text(.2,.35,'细胞内：K⁺相对多，存在不易透膜的A⁻',fontsize=18,color=DARK)
for xx,yy,t,c in [(1,5.5,'Na⁺',RED),(2,4.6,'Na⁺',RED),(3.3,5.4,'Na⁺',RED),(6,5.5,'K⁺',BLUE),(7.1,5.45,'Na⁺',RED),(10.9,5.4,'Na⁺',RED),(1,1.4,'K⁺',BLUE),(2.4,2,'K⁺',BLUE),(3.5,1.2,'A⁻',GREY),(5.8,1.3,'K⁺',BLUE),(6.9,2,'A⁻',GREY),(8.4,1.3,'K⁺',BLUE),(11,1.4,'A⁻',GREY)]:
 ax.add_patch(Circle((xx,yy),.28,fc='white',ec=c,lw=1.5));ax.text(xx,yy,t,color=c,ha='center',va='center',fontsize=12)
for xx,c in [(2.9,BLUE),(5.5,RED),(9.3,PURPLE)]:ax.add_patch(FancyBboxPatch((xx-.35,2.45),.7,1.1,boxstyle='round,pad=.08,rounding_size=.22',fc='white',ec=c,lw=2))
ax.annotate('',(2.9,4.35),(2.9,1.9),arrowprops=dict(arrowstyle='->',color=BLUE,lw=3))
ax.text(1.45,3.78,'K⁺漏通道',color=BLUE,fontsize=15);ax.text(3.32,3.74,'浓度梯度推动外流',fontsize=12,color=BLUE)
ax.annotate('',(4.35,2),(4.35,4.25),arrowprops=dict(arrowstyle='->',color=GREY,lw=2))
ax.text(3.9,1.7,'电位差阻碍继续外流',fontsize=12,color=GREY)
ax.text(5.35,4.6,'静息时Na⁺通透性较低',fontsize=13,color=RED)
ax.annotate('',(8.8,4.6),(8.8,1.9),arrowprops=dict(arrowstyle='->',color=RED,lw=2.3));ax.text(7.9,4.8,'3 Na⁺外运',color=RED,fontsize=13)
ax.annotate('',(9.8,1.9),(9.8,4.6),arrowprops=dict(arrowstyle='->',color=BLUE,lw=2.3));ax.text(9.7,4.8,'2 K⁺内运',color=BLUE,fontsize=13)
ax.text(9.2,3.0,'泵',ha='center',va='center',color=PURPLE,fontsize=17);ax.text(9.0,1.65,'消耗ATP，维持离子梯度',color=PURPLE,fontsize=13)
ax.text(.2,2.35,'膜内侧相对负',fontsize=13,color=DARK);ax.text(.2,3.52,'膜外侧相对正',fontsize=13,color=DARK)
ax.text(.3,5.97,'图示表达相对分布与跨膜方向，不按离子数量或结构尺寸比例。',fontsize=11,color=GREY)
save(f,'fig2_5_resting_potential')
# fig2-6: a smooth qualitative AP curve, not measured data.
x=np.linspace(0,6,900)
xp=np.array([0,.8,1.0,1.11,1.22,1.33,1.46,1.62,1.82,2.15,2.55,3.2,4.2,5.3,6])
yp=np.array([-90,-90,-65,-15,30,15,-30,-70,-84,-88,-95,-94,-92,-90,-90])
from scipy.interpolate import PchipInterpolator
v=PchipInterpolator(xp,yp)(x)
f,ax=plt.subplots(figsize=(10.5,5.7));ax.plot(x,v,color=RED,lw=3)
ax.axhline(-90,color=GREY,ls='--',lw=1);ax.axhline(-60,color=GOLD,ls=':',lw=1.5)
ax.set(xlim=(0,6),ylim=(-105,45),ylabel='膜电位（mV）',xlabel='时间（示意，不表示固定时程）',yticks=[-90,-60,0,30],xticks=[])
ax.text(4.7,-85,'静息电位',fontsize=13,color=GREY);ax.text(4.7,-55,'阈电位示意',fontsize=13,color='#A97818')
for label,xy,xytext in [('上升支：去极化、反极化',(1.14,0),(2.2,29)),('下降支：复极化',(1.52,-48),(2.5,-10)),('后电位与恢复',(3.1,-94),(3.2,-70))]:ax.annotate(label,xy,xytext,color=DARK,arrowprops={'arrowstyle':'->','color':DARK},fontsize=14)
ax.text(.15,-100,'−90 mV与峰值约+30 mV为图示例值',color=GREY,fontsize=10)
save(f,'fig2_6_action_potential')
# fig2-7: absolute/relative/supernormal/subnormal; qualitative and phase-aligned.
f,(a,b)=plt.subplots(2,1,figsize=(11,7),sharex=True,gridspec_kw={'height_ratios':[1.25,1]})
bounds=[.8,1.55,1.95,2.4,5.3];colors=['#EFC9CD','#FFE5C4','#D8EDD7','#DCE9F4'];names=['绝对不应期','相对不应期','超常期','低常期']
a.plot(x,v,color=RED,lw=2.8);a.axhline(-90,color=GREY,ls='--',lw=1);a.set(ylim=(-105,45),yticks=[-90,0,30],ylabel='膜电位（mV）');a.text(4.9,-82,'静息电位',color=GREY,fontsize=11)
ex=PchipInterpolator([0,.79,.8,1.54,1.55,1.75,1.95,2.15,2.4,3,4.3,5.3,6],[100,100,0,0,20,70,100,117,100,83,91,100,100])(x)
b.plot(x,ex,color=BLUE,lw=2.8);b.axhline(100,color=GREY,ls='--',lw=1);b.set(ylim=(-8,145),yticks=[0,100],yticklabels=['0','100%'],ylabel='相对兴奋性',xlabel='时间（示意，不表示固定时程）',xticks=[])
for i,name in enumerate(names):
 for z in [a,b]:z.axvspan(bounds[i],bounds[i+1],color=colors[i],alpha=.55,zorder=0)
 # Place phase labels below, with leaders to narrow phases.
 center=(bounds[i]+bounds[i+1])/2
 tx=[.95,2.25,3.55,5.0][i]
 b.annotate(name,(center,125),(tx,135),ha='center',fontsize=12,color=DARK,arrowprops=dict(arrowstyle='-',color=GREY,lw=.8))
b.set_xlim(0,6)
f.text(.12,.01,'依据教材图2-7作定性重绘；阶段持续时间因细胞类型与条件而异。',fontsize=11,color=GREY)
save(f,'fig2_7_excitability')
# Additional propagation image: changes occur at adjacent membrane locations.
f,ax=plt.subplots(figsize=(12,3.8));ax.axis('off');ax.set(xlim=(0,12),ylim=(0,4))
for i in range(3):
 y=3.3-i*1.1
 ax.add_patch(FancyBboxPatch((1,y-.36),10,.72,boxstyle='round,pad=.01,rounding_size=.3',fc='#EFF4F7',ec='#BAC8D2'))
 ax.add_patch(FancyBboxPatch((1.5+i*2.6,y-.36),1.8,.72,boxstyle='round,pad=.01,rounding_size=.3',fc='#F4B6B6',ec=RED))
 ax.text(.45,y,f'{i+1}',ha='center',va='center',fontsize=16,color=DARK)
 ax.text(2.4+i*2.6,y,'兴奋区',ha='center',va='center',fontsize=13,color=DEEP if False else RED)
 if i<2:ax.annotate('',(6.4+i*1.8,y+.08),(4.8+i*1.8,y+.08),arrowprops=dict(arrowstyle='->',color=BLUE,lw=2))
ax.text(6,.1,'相邻膜区依次产生动作电位，幅度不因传导距离而递减。',ha='center',fontsize=14,color=DARK)
save(f,'propagation')
print('Color scientific figures rendered')
