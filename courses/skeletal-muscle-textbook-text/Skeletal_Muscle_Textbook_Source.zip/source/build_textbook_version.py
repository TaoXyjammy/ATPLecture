from pathlib import Path
import json,copy
from PIL import Image
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
ROOT=Path(__file__).resolve().parent.parent;AS=Path(__file__).parent/'assets'
data=json.loads((Path(__file__).parent/'textbook_text.json').read_text())
# Merge short adjacent paragraphs while retaining every original sentence and order.
data[0]['body']+=data[1]['body'];data.pop(1)
for i,r in enumerate(data):
 if r['page']=='16' and r['title']=='（一）静息电位' and len(r['body'])==1:
  data[i-1]['body']+=r['body'];data[i-1]['layout']='text';data[i-1].pop('figure',None);data[i-1].pop('caption',None);data.pop(i);break
p=Presentation(str(Path(__file__).parent/'肌骨概述.pptx'))
for sid in list(p.slides._sldIdLst):p.part.drop_rel(sid.rId);p.slides._sldIdLst.remove(sid)
RED='C72F3A';ACC='FF4726';DEEP='A71D25';BLUE='287DB2';GOLD='B78117';GREEN='458736';PURPLE='8051A6';DARK='263442';GREY='697580';WHITE='FFFFFF'
records=[]
def box(s,x,y,w,h,c):
 o=s.shapes.add_shape(1,Inches(x),Inches(y),Inches(w),Inches(h));o.fill.solid();o.fill.fore_color.rgb=RGBColor.from_string(c);o.line.fill.background();return o
def tx(s,x,y,w,h,t,size=21,c=DARK,bold=False,align=None):
 o=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));f=o.text_frame;f.word_wrap=True;f.margin_left=f.margin_right=Inches(.025);f.margin_top=Inches(.025);f.margin_bottom=0
 for i,line in enumerate(t.split('\n')):
  q=f.paragraphs[0] if i==0 else f.add_paragraph();q.text=line;q.font.name='Noto Sans CJK SC';q.font.size=Pt(size);q.font.color.rgb=RGBColor.from_string(c);q.font.bold=bold;q.space_after=Pt(10);q.line_spacing=Pt(size*1.28)
  if align is not None:q.alignment=align
 return o
def pic(s,name,x,y,w,h,region=(0,0,1,1)):
 im=Image.open(AS/name);iw,ih=im.size;l,t,r,b=region;ar=iw*(r-l)/(ih*(b-t))
 if ar>w/h:hh=w/ar;ww=w;xx=x;yy=y+(h-hh)/2
 else:ww=h*ar;hh=h;xx=x+(w-ww)/2;yy=y
 z=s.shapes.add_picture(str(AS/name),Inches(xx),Inches(yy),Inches(ww),Inches(hh));z.crop_left=l;z.crop_top=t;z.crop_right=1-r;z.crop_bottom=1-b
 return xx,yy,ww,hh
def lab(s,x,y,w,t,c=DARK):box(s,x,y,w,.34,WHITE);tx(s,x,y,w,.33,t,15,c,True)
def base(r):
 s=p.slides.add_slide(p.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor.from_string(WHITE)
 box(s,0,0,13.333,.2,ACC);tx(s,.6,.4,12,.42,'第二章 运动与骨骼肌',15,DEEP,True)
 tx(s,.6,1.04,12,.65,r['title'],28,DARK,True);box(s,.62,1.87,.8,.045,RED)
 box(s,0,7.14,13.333,.06,ACC);tx(s,.62,6.82,11.2,.23,'《运动生理学》（第6版）  ·  第'+r['page']+'页',10,GREY)
 tx(s,12.1,6.78,.6,.3,f'{len(records)+1:02}',12,DEEP,True,PP_ALIGN.RIGHT)
 tr=OxmlElement('p:transition');tr.set('spd','med');tr.append(OxmlElement('p:fade'));s._element.append(tr)
 return s
# Cover uses the original chapter/section/part titles.
s=p.slides.add_slide(p.slide_layouts[6]);box(s,0,0,5.5,7.5,DEEP);pic(s,'fig2_1_ultrastructure.png',5.65,.55,7.4,6.4)
tx(s,.6,.75,4.4,.55,'第二章 运动与骨骼肌',22,WHITE,True)
tx(s,.6,1.8,4.35,1.65,'第一节\n骨骼肌的结构特点与收缩原理',28,WHITE,True)
tx(s,.65,4.05,4.25,1.9,'一、骨骼肌的超微结构及肌丝滑行学说\n二、骨骼肌细胞的生物电现象',20,WHITE)
tx(s,.65,6.45,4.1,.5,'主讲：谢淘',22,WHITE)
s.notes_slide.notes_text_frame.text='第一节 骨骼肌的结构特点与收缩原理\n一、骨骼肌的超微结构及肌丝滑行学说\n二、骨骼肌细胞的生物电现象'
records.append({'slide':1,'title':'第一节 骨骼肌的结构特点与收缩原理','page':'12—18','body':[]})
for r in data:
 s=base(r);hasfig=bool(r.get('figure'));wide=r.get('layout')=='wide';textonly=r.get('layout')=='text'
 if wide:
  a=pic(s,r['figure'],.7,2.1,11.9,3.1)
  for x,w,t,c in [(1,2,'肌动蛋白',BLUE),(3.15,2.5,'原肌球蛋白',GOLD),(5.9,2.15,'肌钙蛋白C',GREEN),(8.1,2.15,'肌钙蛋白T',PURPLE),(10.3,2.15,'肌钙蛋白I',RED)]:tx(s,x,5.13,w,.37,t,16,c,True)
  tx(s,.85,5.72,11.7,.6,'\n'.join(r['body']),21)
 elif textonly or not hasfig:
  tx(s,.95,2.3,11.45,4.2,'\n'.join(r['body']),22)
 else:
  fig=r['figure'];legend=bool(r.get('legend'));h=3.72 if legend else 4.2
  a=pic(s,fig,.6,2.13,6.3,h,r.get('region',(0,0,1,1)))
  if r.get('subheading'):
   tx(s,7.2,2.16,5.5,1.5,r['body'][0],20.5)
   tx(s,7.2,3.8,5.5,.4,r['subheading'],21,DEEP,True)
   tx(s,7.2,4.45,5.5,1.9,'\n'.join(r['body'][1:]),20.5)
  else:tx(s,7.2,2.16,5.5,3.85 if legend else 4.45,'\n'.join(r['body']),19.5 if sum(map(len,r['body']))>170 else 20.5)
  xx,yy,ww,hh=a
  if fig=='fig2_1_ultrastructure.png' and not r.get('region'):
   for fx,fy,t in [(.66,.05,'肌肉'),(.70,.28,'肌束'),(.79,.48,'肌纤维'),(.02,.68,'肌原纤维'),(.02,.83,'肌球蛋白'),(.02,.94,'肌动蛋白')]:lab(s,xx+ww*fx,yy+hh*fy,1.25,t,BLUE if t=='肌动蛋白' else DARK)
  if fig=='fig2_2_tubules.png':
   if r.get('region'):
    for fy,t,c in [(.04,'终末池',BLUE),(.43,'横管',GOLD),(.79,'终末池',BLUE)]:lab(s,xx+.1,yy+hh*fy,1.9,t,c)
   else:
    for fx,fy,t,c in [(.01,.05,'肌膜',DARK),(.42,.15,'肌浆网',BLUE),(.01,.53,'横管',GOLD),(.60,.46,'三联管',DARK)]:lab(s,xx+ww*fx,yy+hh*fy,1.25,t,c)
  if fig=='fig2_1_ultrastructure.png' and r.get('region')==[.35,.765,.89,.915]:lab(s,1.15,2.6,2.5,'肌球蛋白 头部',RED)
 if r.get('caption'):
  if r.get('legend'):
   tx(s,.7,6.02,11.9,.3,r['caption'],14,GREY,False,PP_ALIGN.CENTER)
   tx(s,.75,6.37,11.75,.4,r['legend'],11.5,GREY)
  else:tx(s,.7,6.45,6.25 if not wide else 11.9,.3,r['caption'],14,GREY,False,PP_ALIGN.CENTER)
 s.notes_slide.notes_text_frame.text='\n\n'.join(r['body'])+'\n\n'+r.get('caption','')+'\n'+r.get('legend','')
 z=copy.deepcopy(r);z['slide']=len(records)+1;records.append(z)
p.save(ROOT/'Skeletal_Muscle_Textbook_Text.pptx')
(ROOT/'原文配文与页码.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
(ROOT/'教材原文配文.md').write_text('# 第一节 骨骼肌的结构特点与收缩原理\n\n'+'\n\n'.join(f'## 第{r["slide"]}页 {r["title"]}\n\n教材第{r["page"]}页\n\n'+ '\n\n'.join(r.get('body',[]))+'\n\n'+r.get('caption','')+'\n'+r.get('legend','') for r in records))
print('Built',len(p.slides),'slides; original body chars',sum(sum(map(len,r.get('body',[]))) for r in records))
