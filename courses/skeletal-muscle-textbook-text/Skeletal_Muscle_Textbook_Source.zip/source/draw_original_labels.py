from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle,Circle,FancyBboxPatch
from scipy.interpolate import PchipInterpolator
AS=Path(__file__).parent/'assets'
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams.update({'font.family':['Noto Sans CJK JP','DejaVu Sans'],'font.size':16,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False})
RED='#C72F3A';BLUE='#287DB2';PURPLE='#8051A6';GOLD='#C39638';DARK='#263442';GREY='#73808C'
def save(f,n):
 for ext in ['png','svg']:f.savefig(AS/(n+'.'+ext),dpi=220,bbox_inches='tight',pad_inches=.12,facecolor='white')
 plt.close(f)
def sar(ax,half,y):
 ax.add_patch(Rectangle((-2.7,y-.36),5.4,.72,color=RED,alpha=.09))
 for dy in [-.24,0,.24]:
  ax.plot([-2.7,2.7],[y+dy,y+dy],lw=5,color=RED,solid_capstyle='round')
  ax.plot([-half,-half+4],[y+dy+.10]*2,lw=2.6,color=BLUE)
  ax.plot([half-4,half],[y+dy+.10]*2,lw=2.6,color=BLUE)
 for x in [-half,half]:ax.plot([x,x],[y-.44,y+.44],lw=3,color=PURPLE)
f,ax=plt.subplots(figsize=(12,6));ax.set(xlim=(-6.5,8),ylim=(0,6));ax.axis('off')
sar(ax,5,4.9);sar(ax,4,2.9);sar(ax,6,.9)
ax.text(0,5.65,'粗肌丝',ha='center',color=RED);ax.text(5,5.65,'细肌丝',ha='center',color=BLUE)
ax.text(4.7,2.9,'缩短的肌节',va='center');ax.text(6.1,.9,'舒张的肌节',va='center')
save(f,'fig2_4_sliding')
f,ax=plt.subplots(figsize=(11,4));ax.set(xlim=(-6,6),ylim=(-1,2.5));ax.axis('off');sar(ax,5,.35)
for xx,t in [(-5,'Z线'),(5,'Z线'),(0,'H区')]:ax.text(xx,1.15,t,ha='center',color=PURPLE if 'Z' in t else GREY)
ax.plot([-2.7,2.7],[1.8,1.8],color=RED,lw=2);ax.text(0,1.9,'A带',ha='center',color=RED)
ax.text(-4,-.6,'I带',ha='center',color=BLUE);ax.text(4,-.6,'I带',ha='center',color=BLUE)
ax.text(-3.6,2.15,'细肌丝',ha='center',color=BLUE);ax.text(3.6,2.15,'粗肌丝',ha='center',color=RED)
save(f,'sarcomere_original_labels')
# Original figure2-5 labels only: no added numerical pump stoichiometry or explanatory prose.
f,ax=plt.subplots(figsize=(10,6));ax.axis('off');ax.set(xlim=(0,10),ylim=(0,6))
for yy in [2.6,3.2]:
 for xx in np.arange(.3,9.8,.3):
  ax.add_patch(Circle((xx,yy),.08,fc='#E8BD80',ec='#AE8145',lw=.5));ax.plot([xx,xx],[yy,2.9],lw=1.0,color='#C79B5E')
ax.text(.2,5.5,'细胞外',fontsize=19,color=DARK);ax.text(.2,.25,'细胞内',fontsize=19,color=DARK);ax.text(.05,3.48,'细胞膜',fontsize=16,color=DARK)
for xx,yy,t,c in [(1,4.7,'K⁺',BLUE),(1.8,4,'Na⁺',RED),(4.1,5,'K⁺',BLUE),(6.5,4.7,'Na⁺',RED),(8.5,4.9,'Na⁺',RED),(1.2,1.4,'K⁺',BLUE),(3.1,1.3,'K⁺',BLUE),(4.4,.8,'K⁺',BLUE),(7,1.3,'K⁺',BLUE),(8.7,1,'A⁻',GREY)]:
 ax.add_patch(Circle((xx,yy),.23,fc='white',ec=c,lw=1.4));ax.text(xx,yy,t,ha='center',va='center',color=c,fontsize=13)
ax.add_patch(FancyBboxPatch((3.4,2.3),.5,1.2,boxstyle='round,pad=.05',fc='white',ec=RED,lw=2));ax.text(2.5,3.85,'钠离子通道',color=RED,fontsize=15)
ax.add_patch(FancyBboxPatch((5.2,2.3),.5,1.2,boxstyle='round,pad=.05',fc='white',ec=BLUE,lw=2));ax.text(4.7,2.0,'钾离子通道',color=BLUE,fontsize=15)
ax.annotate('',(5.45,4.1),(5.45,1.5),arrowprops=dict(arrowstyle='->',color=BLUE,lw=2.5))
ax.add_patch(FancyBboxPatch((7.8,2.3),.65,1.2,boxstyle='round,pad=.1',fc='white',ec=PURPLE,lw=2));ax.text(8.1,2.9,'钠—钾泵',ha='center',va='center',rotation=90,color=PURPLE,fontsize=15)
ax.annotate('',(7.5,4),(7.5,1.6),arrowprops=dict(arrowstyle='->',color=RED,lw=2));ax.annotate('',(8.9,1.6),(8.9,4),arrowprops=dict(arrowstyle='->',color=BLUE,lw=2))
ax.add_patch(FancyBboxPatch((.3,1.7),1.4,.45,boxstyle='round,pad=.1',fc='#F0F2F5',ec=GREY));ax.text(1,1.92,'蛋白质',ha='center',va='center',fontsize=14,color=GREY)
for xx in [2.1,2.6,3.1]:ax.text(xx,3.55,'+',ha='center',color=RED);ax.text(xx,2.15,'−',ha='center',color=BLUE)
save(f,'fig2_5_resting_potential')
x=np.linspace(0,6,900);xp=[0,.8,1,1.11,1.22,1.33,1.46,1.62,1.82,2.15,2.55,3.2,4.2,5.3,6];yp=[-90,-90,-65,-15,30,15,-30,-70,-84,-88,-95,-94,-92,-90,-90];v=PchipInterpolator(xp,yp)(x)
f,ax=plt.subplots(figsize=(10,6));ax.plot(x,v,c=RED,lw=3);ax.axhline(-90,c=GREY,ls='--',lw=1);ax.axhline(-60,c=GOLD,ls='--',lw=1)
ax.set(xlim=(0,6),ylim=(-105,45),yticks=[-90,-60,-30,0,30],xticks=[],ylabel='细胞膜内电位（mV）',xlabel='时间（ms）')
for xx,yy,a in [(.8,-98,'a'),(1.22,35,'b'),(1.62,-67,'c'),(5.3,-87,'d')]:ax.text(xx,yy,a,fontsize=15,color=DARK)
ax.text(4.85,-56,'阈电位',color=GOLD);ax.text(4.85,-84,'静息电位',color=GREY);ax.annotate('超射',(1.24,15),(2.0,13),arrowprops={'arrowstyle':'-','color':GREY},color=DARK)
save(f,'fig2_6_action_potential')
f,(a,b)=plt.subplots(2,1,figsize=(10,7),sharex=True,gridspec_kw={'height_ratios':[1.2,1]})
a.plot(x,v,c=RED,lw=2.8);a.axhline(-90,c=GREY,ls='--',lw=1);a.set(ylim=(-105,45),yticks=[-90,0,30],ylabel='细胞膜内电位（mV）');a.text(2.6,-12,'动作电位曲线',color=RED);a.text(5.1,-82,'静息电位',fontsize=13,color=GREY)
ex=PchipInterpolator([0,.79,.8,1.54,1.55,1.75,1.95,2.15,2.4,3,4.3,5.3,6],[100,100,0,0,20,70,100,117,100,83,91,100,100])(x)
b.plot(x,ex,c=BLUE,lw=2.8);b.axhline(100,c=GREY,ls='--',lw=1);b.set(ylim=(-8,140),yticks=[0,100],yticklabels=['0','100%'],ylabel='兴奋性水平',xlabel='时间（ms）',xticks=[.8,1.55,2.4,5.3],xticklabels=['a','b','c','d']);b.text(3.5,47,'兴奋性变化曲线',color=BLUE);b.text(5.1,108,'正常水平',fontsize=13,color=GREY)
for xx in [.8,1.55,2.4,5.3]:
 for ax in [a,b]:ax.axvline(xx,c=GREY,ls=':',lw=1)
a.set_xlim(0,6);save(f,'fig2_7_excitability')
print('Original-label figures ready')
