from pathlib import Path
import json
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
ROOT=Path(__file__).resolve().parent.parent;FIG=Path(__file__).parent/'figures'
rows=json.loads((Path(__file__).parent/'ppt_content.json').read_text());D=Document();sec=D.sections[0]
sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.top_margin=Cm(1.55);sec.bottom_margin=Cm(1.55);sec.left_margin=sec.right_margin=Cm(1.8);sec.header_distance=sec.footer_distance=Cm(.65)
RED='A92C32';BLUE='276380';DARK='263442';GREY='68737D'
for name in ['Normal','Body Text']:
 st=D.styles[name];st.font.name='Noto Serif CJK SC';st.font.size=Pt(10.5);st.element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Serif CJK SC');st.paragraph_format.line_spacing=Pt(15.5);st.paragraph_format.space_after=Pt(4)
for name,size in [('Title',22),('Heading 1',16),('Heading 2',12.5),('Heading 3',11)]:
 st=D.styles[name];st.font.name='Noto Sans CJK SC';st.element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');st.font.size=Pt(size);st.font.bold=True;st.font.color.rgb=RGBColor.from_string(RED);st.paragraph_format.space_after=Pt(6);st.paragraph_format.space_before=Pt(5)
# Headers and page fields.
p=sec.header.paragraphs[0];p.text='运动生理学  /  骨骼肌的结构特点与收缩原理';p.style='Normal'
for r in p.runs:r.font.size=Pt(8.5);r.font.color.rgb=RGBColor.from_string(GREY)
pPr=p._p.get_or_add_pPr();b=OxmlElement('w:pBdr');bt=OxmlElement('w:bottom');bt.set(qn('w:val'),'single');bt.set(qn('w:sz'),'10');bt.set(qn('w:color'),RED);b.append(bt);pPr.append(b)
p=sec.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.RIGHT;p.add_run('谢淘｜教案    ')
f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');p._p.append(f)
for r in p.runs:r.font.size=Pt(8.5);r.font.color.rgb=RGBColor.from_string(GREY)
def shade(c,color):
 pr=c._tc.get_or_add_tcPr();z=OxmlElement('w:shd');z.set(qn('w:fill'),color);pr.append(z)
def margins(c):
 pr=c._tc.get_or_add_tcPr();mar=OxmlElement('w:tcMar')
 for a in ['top','left','bottom','right']:
  z=OxmlElement('w:'+a);z.set(qn('w:w'),'85');z.set(qn('w:type'),'dxa');mar.append(z)
 pr.append(mar)
def setrun(r,bold=False,size=None,color=None):
 r.font.name='Noto Serif CJK SC';r._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'Noto Serif CJK SC');r.font.bold=bold
 if size:r.font.size=Pt(size)
 if color:r.font.color.rgb=RGBColor.from_string(color)
def para(obj,t='',bold=False,size=None,color=None):
 p=obj.add_paragraph();setrun(p.add_run(t),bold,size,color);return p
def heading(t,level=1,new=False):
 p=D.add_paragraph(t,style='Heading '+str(level));p.paragraph_format.page_break_before=new;return p
def small(c,t):return para(c,t,size=9,color=GREY)
def table(parent,heads,data,widths=None,fs=9.5):
 t=parent.add_table(rows=1,cols=len(heads));t.style='Table Grid';t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
 if widths:
  for c,w in zip(t.columns,widths):c.width=Cm(w)
 for c,v in zip(t.rows[0].cells,heads):
  c.text=v;shade(c,'F4E4E4')
  for p in c.paragraphs:
   for r in p.runs:setrun(r,True,fs,RED)
 trPr=t.rows[0]._tr.get_or_add_trPr();rep=OxmlElement('w:tblHeader');trPr.append(rep)
 for row in data:
  rr=t.add_row()
  for c,v in zip(rr.cells,row):
   c.text=str(v)
   for p in c.paragraphs:
    p.paragraph_format.line_spacing=Pt(fs*1.35);p.paragraph_format.space_after=Pt(2)
    for r in p.runs:setrun(r,size=fs)
 for row in t.rows:
  for c in row.cells:c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.TOP;margins(c)
 return t
def meta(label,text):
 p=D.add_paragraph();setrun(p.add_run(label+'：'),True);setrun(p.add_run(text));return p
# Page 1: generic university teaching plan, not an institutional identity claim.
p=D.add_paragraph('授课教案',style='Title');p.alignment=WD_ALIGN_PARAGRAPH.CENTER
p=D.add_paragraph('骨骼肌的结构特点与收缩原理',style='Heading 1');p.alignment=WD_ALIGN_PARAGRAPH.CENTER
T=table(D,['项目','授课信息'],[
('课程名称','运动生理学'),('授课教师','谢淘'),('授课内容','第二章 运动与骨骼肌\n第一节 第一、第二部分'),('授课对象','体育学相关专业本科生'),('课时安排','2课时，共90分钟（每课时45分钟）'),('授课类型','理论课：讲授、识图、比较与课堂练习'),('教材及配套课件','《运动生理学》（第6版），第12—18页\n配套PPT：教材原文配文版，共26页'),('班级／日期','班级：____________    日期：____________')],[3.4,14.0],10)
heading('一、学情分析',2)
para(D,'适用于已学习基础解剖学和细胞结构知识的本科生。课前用结构识图与“膜内负电位”的含义检查先备知识；对肌纤维、肌原纤维、肌丝等易混淆层级，以同图逐级定位加以澄清。')
heading('二、教学目标',2)
for t in ['知识：辨认肌纤维、肌原纤维、肌小节及主要条带；说出肌管系统与粗、细肌丝组成，解释肌丝滑行时的结构变化。','能力：依据示意图说明静息电位和动作电位的基本过程；比较四个兴奋性阶段，区分细胞内传导与细胞间传递。','科学素养：依据图示和条件作出解释，区分示意模型与实测数据，避免把单个细胞动作电位的幅度等同于整块肌肉的力量。']:
 para(D,t)
# Page 2: focus, methods and exact time budget.
heading('三、教学重点、难点与方法',new=True)
meta('重点','肌小节的界定与条带分布；肌丝滑行学说；静息电位、动作电位及兴奋性变化。')
meta('难点','粗、细肌丝长度与重叠程度的区别；浓度梯度和电位差的共同作用；动作电位与兴奋性曲线的时间对应。')
meta('教学方法','图示讲解、对照比较、定向提问、学生指图复述、随堂检验。')
meta('教学准备','26页配套PPT；图2-1至图2-7的彩色配图；投影设备、白板；可选的肌小节空白图。')
heading('四、教学进度与时间分配',2)
schedule=[('第一课时','组织教学与导入','5','1—2'),('第一课时','结构层级与肌原纤维','5','2—3'),('第一课时','肌小节与肌丝排列','7','4—6'),('第一课时','肌管系统','7','7—8'),('第一课时','肌丝的分子组成','8','9—11'),('第一课时','肌丝滑行学说','10','12—13'),('第一课时','课堂小结','3','2—13'),('第二课时','衔接与生物电概述','5','14—15'),('第二课时','静息电位','14','16—19'),('第二课时','动作电位','12','20—23'),('第二课时','兴奋性变化、特点与传导','8','24—26'),('第二课时','巩固检测','4','全课'),('第二课时','布置作业','2','全课')]
table(D,['课时','环节','分钟','PPT页码'],schedule,[2.2,10.2,1.7,3.3],9)
para(D,'第一课时45分钟；第二课时45分钟；合计90分钟。',bold=True,size=10,color=RED)
heading('五、评价方式',2)
para(D,'通过指图、口头解释和简答检测，分别检查“识别结构—解释滑行—说明离子方向—对应兴奋性阶段”四项表现。课堂未达成的目标在下次课复查，课后反思据实际授课填写。')
# Original textbook paragraphs are copied from the exact latest PPT content map.
def get_rows(a,b):return [r for r in rows if a<=r['slide']<=b]
def quote(c,a,b):
 for r in get_rows(a,b):
  if r.get('subheading'):
   para(c,r['body'][0]);para(c,r['subheading'],True,color=RED)
   for q in r['body'][1:]:para(c,q)
  else:
   for q in r.get('body',[]):para(c,q)
def fig(c,name,caption,width=12.25):
 p=c.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.space_after=Pt(1);p.paragraph_format.line_spacing=1.0;p.add_run().add_picture(str(FIG/(name+'.png')),width=Cm(width))
 p=c.add_paragraph(caption);p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.space_after=Pt(4)
 for r in p.runs:setrun(r,size=9,color=GREY)
def process(title,side,source,activity,learn,check,new=True):
 heading(title,new=new)
 t=D.add_table(rows=1,cols=2);t.style='Table Grid';t.autofit=False;t.columns[0].width=Cm(2.9);t.columns[1].width=Cm(14.5)
 left,right=t.rows[0].cells;left.width=Cm(2.9);right.width=Cm(14.5);shade(left,'FBF0EE')
 for c in [left,right]:c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.TOP;margins(c)
 left.paragraphs[0].text='时间与教法'
 for rr in left.paragraphs[0].runs:setrun(rr,True,10,RED)
 for a in side:para(left,a,size=9.5)
 para(left,'课件与教材',True,10,RED);para(left,source,size=9.5)
 right.paragraphs[0].text='教学内容（教材原文）'
 for rr in right.paragraphs[0].runs:setrun(rr,True,10.5,RED)
 # Return callbacks stored so actions appear after the source paragraph and figure.
 def end():
  for head,txt in [('教师活动',activity),('学生活动',learn),('检查与预期',check)]:
   pp=right.add_paragraph();setrun(pp.add_run(head+'：'),True,10,BLUE);setrun(pp.add_run(txt),size=10)
 return right,end
# Page 3.
c,end=process('六、教学过程｜第一课时', ['组织与导入：5分钟','结构层级与肌原纤维：5分钟','识图、定向提问'], 'PPT 1—3\n教材第12页', '先用“肌肉为什么呈现横纹”导入；沿图2-1逐级指认肌肉、肌束、肌纤维和肌原纤维，讲清肌内膜、肌束膜、肌外膜的位置。','按图复述层级；在图中指出暗带与明带。','能正确说出肌纤维是肌细胞，肌原纤维位于肌纤维内部，横纹与A、I带规则交替有关。')
quote(c,2,3);fig(c,'fig2_1','图2-1 骨骼肌超微结构示意图');end()
# Page 4.
c,end=process('（一）肌原纤维和肌小节', ['7分钟','局部放大、比较'], 'PPT 4—6\n教材第13页','先确定Z线，再依次定位A带、I带、H区；用左右Z线之间的范围说明肌小节，强调“肌丝所在位置”与“条带名称”的对应。','在空白图上标注Z线、A带、I带、H区；描述粗、细肌丝重叠区的排列。','能用“两条Z线之间”界定肌小节；辨认A带中既有重叠区也有H区。')
quote(c,4,6);fig(c,'sarcomere','图2-1 骨骼肌超微结构示意图（PPT中的肌小节局部）');end()
# Page 5.
c,end=process('（二）肌管系统', ['7分钟','彩色图示、比较'], 'PPT 7—8\n教材第13—14页','先指认横小管与纵小管，再用局部图说明三联管；让学生比较“相邻”与“相通”，以膜边界作为判断依据。','依据颜色识别横管和肌质网，在图中指认终末池，口头组成“三联管”。','预期回答：一条横小管与两侧终末池；两种小管的内腔不相通。')
quote(c,7,8);fig(c,'fig2_2','图2-2 肌管系统结构示意图');end()
# Page 6.
c,end=process('（三）肌丝的分子组成', ['8分钟','组成识别、图文对应'], 'PPT 9—11\n教材第14页','按教材先讲粗肌丝，再讲细肌丝；指认肌球蛋白头部与横桥，说明ATP酶活性与运动的联系，随后辨认细肌丝三类蛋白。','对照图辨认肌球蛋白、肌动蛋白、原肌球蛋白和肌钙蛋白；用一句话说出粗、细肌丝各自主要组成。','能正确列出粗、细肌丝的主要成分，不把横桥写成细肌丝组成。')
quote(c,9,11);fig(c,'fig2_3','图2-3 细肌丝结构示意图',13.2);end()
# Page 7.
c,end=process('（四）肌丝滑行学说', ['讲解与比较：10分钟','第一课时小结：3分钟','对照观察、口头解释'], 'PPT 12—13\n教材第14—15页','依次比较三种肌节状态，先让学生找不变项，再找变化项；用图中Z线间距与重叠范围支持解释。最后回扣本课时的结构、组成与滑行。','比较A带、I带、H区和Z线间距；同伴间互相解释“肌肉缩短是否等于肌丝变短”。','预期回答：粗、细肌丝长度不变；收缩时Z线靠近，I带、H区变窄，A带长度不变。')
quote(c,12,13);fig(c,'fig2_4','图2-4 肌丝滑行示意图');end()
# Page 8.
c,end=process('第二课时｜二、骨骼肌细胞的生物电现象', ['衔接：2分钟','概述：3分钟','静息电位定义：3分钟','复习、联系记录方法'], 'PPT 14—16\n教材第15页','以“有结构基础后，兴奋如何表现”衔接；解释生物电与兴奋性，联系心电图、脑电图、肌电图的记录对象，再明确膜外为零的参照条件。','复述兴奋性的含义；解释静息电位负号所使用的参照，并辨认神经细胞示例。','能说出静息电位是跨膜电位差；“膜内负”是相对膜外电位而言，不是脱离参照的绝对数值。')
quote(c,14,16);end()
# Page 9.
c,end=process('（一）静息电位：离子分布与选择性通透', ['7分钟','识图、条件分析'], 'PPT 17—18\n教材第15—16页','将“内外浓度差”与“膜选择性通透”分开指出；让学生先按自由扩散趋势判断方向，再加入静息膜通透性的条件。','在图上指认细胞内外、离子通道和蛋白质；解释为什么浓度差本身还不足以确定实际跨膜流动。','能把“如果允许自由通过”的假设，与“静息膜有选择性通透”的实际条件区分开。')
quote(c,17,18);fig(c,'fig2_5','图2-5 静息电位的形成原理');end()
# Page 10.
c,end=process('（一）静息电位：外流与平衡', ['4分钟','顺序推演、解释'], 'PPT 19\n教材第15—16页','沿原文顺序梳理：K⁺外流、电荷转移、膜内外电位差、相反电场力、净移动量趋零；提问“平衡是否等于完全没有离子运动”。','按原文顺序复述驱动力关系；区别“净移动量为零”与“所有微观运动停止”。','预期回答：向外扩散力与阻止外流的电场力相等时，K⁺净移动量为零，电位差趋于稳定。')
quote(c,19,19);fig(c,'fig2_5','图2-5 静息电位的形成原理',10.5);end()
# Page 11.
c,end=process('（二）动作电位｜1. 动作电位变化过程', ['5分钟','沿曲线描述、标点'], 'PPT 20—21\n教材第16—17页','先明确教材以神经轴突为例，再顺a、b、c、d指图讲解上升支、下降支、锋电位和后电位，统一膜内相对膜外的参照。','在曲线上指出上升支、下降支及后电位；解释去极化、反极化、复极化的方向关系。','能按时间顺序描述电位变化，且不把膜电位的数值下降误写成离子浓度下降。')
quote(c,20,21);fig(c,'fig2_6','图2-6 动作电位示意图（细胞内记录）')
small(c,'ab：动作电位的上升支；bc：动作电位的下降支；abc：动作电位的锋电位；cd：动作电位的后电位。');end()
# Page 12.
c,end=process('2. 动作电位的产生原理', ['7分钟','图文匹配、对照说明'], 'PPT 22—23\n教材第17页','对照曲线说明通道状态、跨膜方向与膜电位变化；分别处理上升支与下降支，明确“Na⁺内流”和“K⁺外流”的对应。','用两列简表写出“上升支／下降支—主要离子方向—电位变化”，再口头说明。','预期回答：Na⁺内流形成上升支；Na⁺通道失活、K⁺外流参与下降支。')
quote(c,22,23);fig(c,'fig2_6','图2-6 动作电位示意图（细胞内记录）',10.5);end()
# Page 13.
c,end=process('（三）兴奋性的变化过程｜（四）动作电位的传导', ['8分钟','上下曲线对照、迁移'], 'PPT 24—26\n教材第17—18页','对齐上下曲线的时间轴，依次读出四个兴奋性阶段；随后说明三个特点及细胞内传导。以完整纤维中段刺激的条件帮助理解双向传播，暂不进入细胞间传递。','指认四个阶段；将“全或无”“不衰减性传导”“脉冲式”分别对应原文；区别沿同一细胞膜传导与下一部分的细胞间传递。','能依据曲线说出四期顺序；能说明不衰减与不应期限制连续反应的含义。')
quote(c,24,26);fig(c,'fig2_7','图2-7 动作电位变化与兴奋性变化之间的关系',11.8)
small(c,'ab：锋电位——绝对不应期；bc：后电位前部——相对不应期、超常期；cd：后电位后部——低常期。');end()
# Final page: closing work and post-lesson reflection without fabricated results.
heading('七、巩固检测、作业与板书',new=True)
heading('1. 巩固检测（4分钟）',2)
checks=[('肌小节的边界是什么？','相邻两条Z线之间。'),('收缩时A带、I带、H区怎样变化？','A带长度不变；I带与H区变窄。'),('动作电位上升支与下降支主要对应什么离子方向？','上升支：Na⁺内流；下降支：K⁺外流。'),('兴奋性变化分为哪四期？','绝对不应期、相对不应期、超常期、低常期。')]
table(D,['检查问题','预期要点'],checks,[8.4,9.0],10)
heading('2. 布置作业（2分钟）',2)
for x in ['完成一幅肌小节标注图，标出Z线、A带、I带、H区，并说明收缩时的变化。','用一段文字区分浓度差、膜选择性通透和静息电位形成之间的关系。','根据图2-6和图2-7说明动作电位变化与兴奋性变化的联系。']:
 para(D,x)
heading('3. 板书设计',2)
table(D,['一、超微结构及肌丝滑行学说','二、骨骼肌细胞的生物电现象'],[('肌纤维→肌原纤维→肌小节\nZ线／A带／I带／H区\n横管＋两侧终末池＝三联管\n粗肌丝／细肌丝\n滑行：肌丝长度不变，重叠改变','静息电位：浓度差＋选择性通透\n动作电位：上升支／下降支／后电位\nNa⁺内流／K⁺外流\n四个兴奋性阶段\n全或无／不衰减性传导／脉冲式')],[8.7,8.7],9.5)
heading('八、教学后记（授课后填写）',2)
para(D,'目标达成与学生困难：________________________________________________')
para(D,'时间执行与改进措施：________________________________________________')
para(D,'需在下次课复查的内容：______________________________________________')
small(D,'教材与课件：《运动生理学》（第6版）第12—18页；26页教材原文配文版PPT。图2-1至图2-7及相关局部均取自该PPT，未另行生成图片。')
small(D,'版式结构参考：registor/nwafuTeachingPlan，首页授课计划与旁注式内容页；本教案以Word独立编排。https://github.com/registor/nwafuTeachingPlan')
D.save(ROOT/'Skeletal_Muscle_Lesson_Plan.docx')
# Evidence for scope, figure reuse and time budget.
manifest={'planned_minutes':90,'period_minutes':[45,45],'ppt_pages':26,'textbook_pages':'12—18','template':'https://github.com/registor/nwafuTeachingPlan','source_ppt':'Skeletal_Muscle_Textbook_Text.pptx','schedule':schedule,'original_paragraphs_included':sum(len(r.get('body',[])) for r in rows),'figures':'源自配套PPT导出，见source/figure_map.json'}
(ROOT/'教案核对.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print('Lesson plan DOCX built; source paragraphs',manifest['original_paragraphs_included'])
